# FoodBridge - Food Donation Management Platform

A complete React frontend prototype that connects food donors with NGOs. It runs **without a backend**: all data is
stored in your browser (localStorage) and every page is fully working. The code is organised so a real backend
(FastAPI, Express or Spring Boot) can be plugged in later by changing one file.

> **Honest scope note.** This repository is the *frontend*. It does not contain SQL, MongoDB, FastAPI, Kafka or
> microservices. It is built to be *ready to connect* to them - see "Implemented now vs needs a backend" below.

---

## 1. Run it in VS Code (beginner steps)

1. Install **Node.js 18 or newer** from https://nodejs.org (choose the LTS version).
2. Open VS Code -> **File -> Open Folder** -> choose the `foodbridge` folder.
3. Open the terminal: **Terminal -> New Terminal**.
4. Install packages (first time only):
   ```bash
   npm install
   ```
5. Start the app:
   ```bash
   npm run dev
   ```
6. Open the link shown (normally http://localhost:5173).

Other commands:

| Command | What it does |
|---|---|
| `npm run build` | Creates the production build in `dist/` |
| `npm run preview` | Serves the production build locally |

## 2. Demo logins (demo authentication only)

On the login page you can click a role button, or type these:

| Role | Email | Password |
|---|---|---|
| Admin | admin@foodbridge.demo | Admin@123 |
| Donor | donor@foodbridge.demo | Donor@123 |
| NGO | ngo@foodbridge.demo | Ngo@1234 |
| Volunteer | volunteer@foodbridge.demo | Volunteer@1 |

You can also register a new account (Admin, Donor, NGO or Volunteer). **This login is not secure**: passwords are plain
text in localStorage. A real system must use hashed passwords and JWT tokens issued by a backend.

Role-aware navigation: Admin sees everything. Donor lists and edits food packages. NGO creates requests and views
insights. Volunteer updates pickup/transit/delivery status on assignments.

## 3. Quick demo script for faculty

1. Log in as **Admin** -> Dashboard shows live metrics, charts and urgent requests.
2. **Food Packages** -> *Add package* (try submitting empty to see validation) -> see it appear first/expiring badges.
3. **NGO Requests** -> approve a pending request -> **Assign** -> choose package and volunteer.
4. **Assignments** -> click *Mark picked up*, *Mark in transit*, *Mark delivered*.
5. **Distribution History** -> the completed delivery is now listed. Go back to the Dashboard: meals served and waste prevented increased.
6. **AI & Demand Insights** -> ranked requests with explainable scores, matches, forecast. Click *Refresh predictions*.
7. **Settings** -> *Reset demo data* restores the sample dataset.

## 4. Project structure

```
src/
  components/
    layout/    Sidebar, Topbar, AppLayout, NotificationPanel, navConfig
    common/    Modal, ConfirmDialog, DataTable, Badge, StatCard, FilterBar, States, Toasts ...
    charts/    ChartCard + Recharts wrappers
    forms/     Donor, NGO, Package, Request, Assignment forms + Fields
  pages/       Dashboard, Donors, FoodPackages, NGOs, Requests, Assignments,
               DistributionHistory, DemandInsights, Analytics, Settings, Login
  services/    api.js (HTTP client) + one file per feature + mockBackend.js (localStorage "server")
  context/     AppContext.jsx (shared state, toasts, auth, actions)
  hooks/       useForm.js
  data/        constants.js, mockData.js (seed dataset)
  utils/       calculations.js, csvExport.js
```

How data flows: **Page -> AppContext action -> service -> api.js -> (mockBackend.js now / real backend later)**.
Pages never touch storage directly.

## 5. Data model (relational-ready)

Every record has a primary key (`id`) and foreign keys, so it maps one-to-one to SQL tables:

| Table | Primary key | Foreign keys |
|---|---|---|
| users | id (U-001) | linkedId -> donors / ngos / volunteers |
| donors | id (D-001) | - |
| ngos | id (N-001) | - |
| volunteers | id (V-01) | - |
| packages | id (P-001) | donorId -> donors |
| requests | id (R-1001) | ngoId -> ngos |
| assignments | id (A-5001) | packageId, requestId, donorId, ngoId, volunteerId |
| distributions | id (H-9001) | assignmentId, packageId, donorId, ngoId |
| notifications | id | - |

Transactions mirrored in `mockBackend.js` (in a real database these would be single SQL transactions):
- **Create assignment**: reduce `packages.availableServings`, set request to *Assigned*, insert assignment, add notification.
- **Mark delivered**: set assignment *Delivered*, set request *Delivered*, insert a `distributions` row.
- **Cancel assignment**: return servings to the package and set request back to *Approved*.

Business rules enforced (client form *and* mock backend): no assigning more than available or needed, no expired or
fully-assigned packages, category must match, NGO must be Verified, only one active assignment per request,
status moves one step at a time, packages with assignments cannot be deleted (foreign-key rule).

Assumptions: 1 meal ~ 0.4 kg of food (`KG_PER_MEAL`); package availability (Available / Fully assigned / Expired) is
*derived* from servings and expiry time, never stored. Older months in analytics are sample history; the current
month adds live records.

## 6. Demand prediction (demo, not machine learning)

`src/services/predictionService.js` contains a transparent formula - **it is not a trained model**.

- Forecast per day = (0.6 x last-7-day average + 0.4 x same-weekday average) x (1 + 0.15 x share of urgent open requests).
- Priority score (0-100) = urgency (35) + beneficiaries (20) + time remaining (25) + matching food available (10) + food expiry (10).
- Matches are greedy: highest score first, and servings already promised are not offered twice.

To connect a Python service, copy `.env.example` to `.env` and set `VITE_API_URL=http://localhost:8000/api`. The page then calls
`GET /predictions/demand`, `GET /predictions/priorities` and `POST /predictions/refresh`. If the API fails, it falls back
to the demo calculation and shows a warning banner. Expected response shapes are the return values of
`demoDemand()` and `demoPriorities()` in that file.

## 7. Course outcome mapping

| CO | Where it appears | What is implemented now | What the backend must provide |
|---|---|---|---|
| **CO1** Relational DB and SQL | All data pages; section 5 above | IDs, primary/foreign keys, joins done in UI (e.g. History joins donor/NGO/package), transaction-style updates | Normalised SQL schema, joins, real transactions |
| **CO2** SQL and NoSQL | Packages (free-form notes/description), NGOs (`requirements` array), notifications | Records with both structured fields and flexible document-like fields | Relational tables for core entities; MongoDB (or JSON columns) for notifications, preferences, prediction logs |
| **CO3** FastAPI, Pydantic, JWT, REST | `services/api.js`, `authService.js`, Login, all service files | One REST client, `Authorization: Bearer` header, FastAPI-style `{detail}` errors, validated forms | FastAPI endpoints, Pydantic models, JWT login, OpenAPI docs |
| **CO4** Node/Express or Spring Boot, service design | `src/services/*`, feature-based pages | API calls separated from components; swap backend by setting `VITE_API_URL` | Express or Spring Boot REST service |
| **CO5** Microservices and Kafka | Notification centre (bell icon), service files named by domain | Mock notifications created on events (new request, approval, expiry, assignment, delivery). **No Kafka runs in the browser.** | User, donation, request, assignment, prediction and notification services; Kafka topics feeding notifications |
| **CO6** Docker, deployment, CI/CD | `Dockerfile`, `nginx.conf`, `.dockerignore`, `.github/workflows/build.yml` | Production build, container image, CI build on every push | Deployment target, extra CI steps for backend |

Page-by-page: Dashboard (CO1, CO5), Donors/NGOs (CO1, CO2, CO3), Food Packages (CO1, CO2), Requests (CO1, CO3, CO5),
Assignments (CO1 transactions, CO4), Distribution History (CO1 joins), AI & Demand Insights (CO3, CO4), Analytics (CO1),
Settings (CO2 preferences, CO6 build config), Login (CO3 JWT-ready).

## 8. Endpoints expected from the future backend

Base URL = `VITE_API_URL`. Errors should return `{ "detail": "message" }` with a 4xx status.

| Method | Path | Purpose |
|---|---|---|
| POST | /auth/login, /auth/register | Returns `{ token, user }` (JWT) |
| GET, POST | /donors | List / create donors |
| PUT | /donors/{id} | Update donor |
| GET, POST | /ngos | List / create NGOs |
| PUT | /ngos/{id} | Update NGO |
| GET, POST | /packages | List / create food packages |
| PUT, DELETE | /packages/{id} | Update / delete (409 if assignments exist) |
| GET, POST | /requests | List / create requests |
| PATCH | /requests/{id}/status | Approve, reject, reopen |
| GET, POST | /assignments | List / create (transaction) |
| PATCH | /assignments/{id}/status | Body `{status}`; moves one step; Delivered also creates a distribution |
| DELETE | /assignments/{id} | Cancel before pickup |
| GET | /distributions | Distribution history |
| GET | /volunteers | Delivery partners |
| GET, PATCH | /notifications, /notifications/{id}/read, /notifications/read-all | Notification service |
| GET, PUT | /settings | Preferences |
| GET | /meta | Chart history (`activityHistory`, `demandHistory`, `monthlyHistory`) |
| GET | /predictions/demand | Demand forecast |
| GET | /predictions/priorities | Ranked requests and matches |
| POST | /predictions/refresh | Re-run predictions |

(`POST /reset` exists only in the mock backend for the demo.)

## 9. Implemented now vs needs a backend

**Implemented in this frontend**
- All 11 screens, role-aware navigation, responsive layout with mobile menu
- Full add/edit/delete flows with validation, confirmations, toasts, loading/empty/error states
- Search, filters, sorting, pagination, global search, CSV export on every main table
- Shared state: assignments update inventory, request status, history, dashboard and analytics
- Notification centre with mock events
- Demo prediction and priority scoring with explanations and API fallback
- localStorage persistence and a reset option
- Dockerfile, nginx config, GitHub Actions build

**Still needs a backend**
- Real authentication (hashed passwords, JWT, refresh, server-side role checks)
- Real database (SQL tables and NoSQL documents), multi-user data, concurrency control
- Trained prediction model and the FastAPI prediction service
- Kafka events and notification service, email/SMS delivery
- Server-side validation and security

## 10. Docker and CI

```bash
docker build -t foodbridge .
docker run -p 8080:80 foodbridge        # open http://localhost:8080

# optional: build against a real backend
docker build --build-arg VITE_API_URL=http://localhost:8000/api -t foodbridge .
```

GitHub Actions (`.github/workflows/build.yml`) runs `npm ci` and `npm run build` on every push and pull request.

## 11. Accessibility notes

Skip link, labelled form fields with error messages, focus moved to the first invalid field, keyboard-operable modals
(Esc closes), `aria-sort` on sortable columns, visible focus rings, and reduced-motion support.
