// Shared constants. Keep enum values here so every page uses the same spelling.
export const CATEGORIES = [
  'Cooked Meals',
  'Bakery & Bread',
  'Fruits & Vegetables',
  'Packaged Food',
  'Dairy & Beverages',
  'Grains & Staples',
]
export const DIETS = ['Vegetarian', 'Non-Vegetarian', 'Vegan', 'Not applicable']
export const UNITS = ['kg', 'litres', 'trays', 'boxes', 'packets', 'loaves']
export const LOCATIONS = [
  'Ameerpet', 'Banjara Hills', 'Gachibowli', 'Kukatpally',
  'LB Nagar', 'Madhapur', 'Secunderabad', 'Uppal',
]
export const URGENCY = ['Low', 'Medium', 'High', 'Critical']
export const REQUEST_STATUSES = ['Pending', 'Approved', 'Rejected', 'Assigned', 'In Transit', 'Delivered']
export const ASSIGNMENT_STATUSES = ['Assigned', 'Picked Up', 'In Transit', 'Delivered']
export const VERIFICATION = ['Verified', 'Pending', 'Unverified']
export const ROLES = ['Admin', 'Donor', 'NGO', 'Volunteer']
export const DONOR_TYPES = ['Restaurant', 'Hostel', 'Event organizer', 'Bakery', 'Canteen', 'Grocery store', 'Trust kitchen', 'Individual']

// Rough planning figure: 1 meal ~ 0.4 kg of food. Used to estimate "waste prevented".
export const KG_PER_MEAL = 0.4
// A package is "expiring soon" when it expires within this many hours.
export const EXPIRING_SOON_HOURS = 6
