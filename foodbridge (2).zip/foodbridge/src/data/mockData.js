// Demo dataset. Tables are shaped like relational tables:
// every record has a primary key (id) and foreign keys such as donorId, ngoId, packageId.
// Times are generated relative to "now" so the demo always has packages that are expiring soon.
import { CATEGORIES, LOCATIONS } from './constants'

const HOUR = 3600 * 1000
const iso = (hoursFromNow) => new Date(Date.now() + hoursFromNow * HOUR).toISOString()
const dayStr = (daysAgo) => new Date(Date.now() - daysAgo * 24 * HOUR).toISOString().slice(0, 10)

// Small deterministic pseudo-random generator so charts look the same after every reset.
function seeded(seed) {
  let s = seed
  return () => {
    s = (s * 9301 + 49297) % 233280
    return s / 233280
  }
}

export function buildSeed() {
  const users = [
    { id: 'U-001', name: 'Priya Menon', email: 'admin@foodbridge.demo', password: 'Admin@123', role: 'Admin', linkedId: null },
    { id: 'U-002', name: 'Anil Reddy', email: 'donor@foodbridge.demo', password: 'Donor@123', role: 'Donor', linkedId: 'D-001' },
    { id: 'U-003', name: 'Suresh Kumar', email: 'ngo@foodbridge.demo', password: 'Ngo@1234', role: 'NGO', linkedId: 'N-001' },
    { id: 'U-004', name: 'Arjun Das', email: 'volunteer@foodbridge.demo', password: 'Volunteer@1', role: 'Volunteer', linkedId: 'V-01' },
  ]

  const donors = [
    { id: 'D-001', name: 'Anil Reddy', organization: 'Paradise Kitchen', type: 'Restaurant', phone: '+91 98480 10001', email: 'anil@paradisekitchen.example', location: 'Banjara Hills', address: 'Road No. 12, Banjara Hills', registeredOn: '2025-03-12', status: 'Active' },
    { id: 'D-002', name: 'Meera Nair', organization: 'Sri Sai Boys Hostel', type: 'Hostel', phone: '+91 98480 10002', email: 'meera@srisaihostel.example', location: 'Kukatpally', address: 'KPHB Colony Phase 3', registeredOn: '2025-04-02', status: 'Active' },
    { id: 'D-003', name: 'Farhan Qureshi', organization: 'Shaadi Mahal Events', type: 'Event organizer', phone: '+91 98480 10003', email: 'farhan@shaadimahal.example', location: 'Secunderabad', address: 'SD Road, Secunderabad', registeredOn: '2025-05-19', status: 'Active' },
    { id: 'D-004', name: 'Kavita Sharma', organization: 'Individual donor', type: 'Individual', phone: '+91 98480 10004', email: 'kavita.sharma@example.com', location: 'Madhapur', address: 'Ayyappa Society, Madhapur', registeredOn: '2025-06-08', status: 'Active' },
    { id: 'D-005', name: 'Rohit Verma', organization: 'Green Leaf Bakery', type: 'Bakery', phone: '+91 98480 10005', email: 'rohit@greenleaf.example', location: 'Gachibowli', address: 'DLF Road, Gachibowli', registeredOn: '2025-07-21', status: 'Active' },
    { id: 'D-006', name: 'Sunita Rao', organization: 'Annapurna Canteen', type: 'Canteen', phone: '+91 98480 10006', email: 'sunita@annapurna.example', location: 'Ameerpet', address: 'Satyam Theatre Road, Ameerpet', registeredOn: '2025-08-30', status: 'Active' },
    { id: 'D-007', name: 'Imran Sheikh', organization: 'Fresh Basket Mart', type: 'Grocery store', phone: '+91 98480 10007', email: 'imran@freshbasket.example', location: 'LB Nagar', address: 'Main Road, LB Nagar', registeredOn: '2025-09-14', status: 'Active' },
    { id: 'D-008', name: 'Lakshmi Devi', organization: 'Temple Trust Kitchen', type: 'Trust kitchen', phone: '+91 98480 10008', email: 'lakshmi@templetrust.example', location: 'Uppal', address: 'Temple Street, Uppal', registeredOn: '2025-10-03', status: 'Inactive' },
  ]

  const ngos = [
    { id: 'N-001', name: 'Hope Foundation Hyderabad', verification: 'Verified', contactPerson: 'Suresh Kumar', phone: '+91 90000 20001', email: 'suresh@hopefoundation.example', address: 'Ameerpet Main Road', serviceArea: 'Ameerpet', beneficiaries: 450, requirements: ['Cooked Meals', 'Grains & Staples'], capacity: 600 },
    { id: 'N-002', name: 'Asha Kiran Trust', verification: 'Verified', contactPerson: 'Deepa Joseph', phone: '+91 90000 20002', email: 'deepa@ashakiran.example', address: 'Trimulgherry, Secunderabad', serviceArea: 'Secunderabad', beneficiaries: 380, requirements: ['Cooked Meals', 'Dairy & Beverages'], capacity: 500 },
    { id: 'N-003', name: 'Seva Sadan', verification: 'Verified', contactPerson: 'Ramesh Babu', phone: '+91 90000 20003', email: 'ramesh@sevasadan.example', address: 'JNTU Road, Kukatpally', serviceArea: 'Kukatpally', beneficiaries: 300, requirements: ['Grains & Staples', 'Fruits & Vegetables'], capacity: 400 },
    { id: 'N-004', name: 'Little Hands Orphanage', verification: 'Verified', contactPerson: 'Sister Anita', phone: '+91 90000 20004', email: 'anita@littlehands.example', address: 'Road No. 3, Banjara Hills', serviceArea: 'Banjara Hills', beneficiaries: 120, requirements: ['Bakery & Bread', 'Dairy & Beverages', 'Fruits & Vegetables'], capacity: 150 },
    { id: 'N-005', name: 'Roti Bank Telangana', verification: 'Verified', contactPerson: 'Naveen Goud', phone: '+91 90000 20005', email: 'naveen@rotibank.example', address: 'Hitech City Road, Madhapur', serviceArea: 'Madhapur', beneficiaries: 520, requirements: ['Cooked Meals', 'Packaged Food'], capacity: 700 },
    { id: 'N-006', name: 'Annadaan Seva Samithi', verification: 'Pending', contactPerson: 'Vijay Kumar', phone: '+91 90000 20006', email: 'vijay@annadaan.example', address: 'Habsiguda, Uppal', serviceArea: 'Uppal', beneficiaries: 210, requirements: ['Dairy & Beverages', 'Cooked Meals'], capacity: 250 },
    { id: 'N-007', name: 'Care & Share Society', verification: 'Verified', contactPerson: 'Fatima Begum', phone: '+91 90000 20007', email: 'fatima@careshare.example', address: 'Nagole Road, LB Nagar', serviceArea: 'LB Nagar', beneficiaries: 280, requirements: ['Fruits & Vegetables', 'Cooked Meals', 'Grains & Staples'], capacity: 350 },
    { id: 'N-008', name: 'Vridha Ashram Trust', verification: 'Pending', contactPerson: 'Gopal Rao', phone: '+91 90000 20008', email: 'gopal@vridhaashram.example', address: 'Financial District, Gachibowli', serviceArea: 'Gachibowli', beneficiaries: 65, requirements: ['Packaged Food', 'Fruits & Vegetables'], capacity: 90 },
  ]

  const volunteers = [
    { id: 'V-01', name: 'Arjun Das', phone: '+91 91000 30001', vehicle: 'Motorbike', area: 'Ameerpet', available: true },
    { id: 'V-02', name: 'Sana Fatima', phone: '+91 91000 30002', vehicle: 'Van', area: 'Secunderabad', available: true },
    { id: 'V-03', name: 'Ravi Teja', phone: '+91 91000 30003', vehicle: 'Van', area: 'Kukatpally', available: true },
    { id: 'V-04', name: 'Pooja Iyer', phone: '+91 91000 30004', vehicle: 'Car', area: 'Madhapur', available: true },
    { id: 'V-05', name: 'Mohan Babu', phone: '+91 91000 30005', vehicle: 'Motorbike', area: 'LB Nagar', available: true },
  ]

  // servings = total servings listed; availableServings = servings still unassigned.
  const pkg = (id, donorId, name, category, description, quantity, unit, servings, availableServings, prepH, expH, location, diet, notes) => ({
    id, donorId, name, category, description, quantity, unit, servings, availableServings,
    preparedAt: iso(prepH), expiresAt: iso(expH), location, diet, notes, createdAt: iso(prepH),
  })
  const packages = [
    pkg('P-001', 'D-001', 'Chicken Biryani (surplus)', 'Cooked Meals', 'Dum biryani from lunch service, packed in foil trays.', 30, 'kg', 120, 60, -3, 5, 'Banjara Hills', 'Non-Vegetarian', 'Keep hot above 60°C. Consume within 5 hours.'),
    pkg('P-002', 'D-002', 'Veg Meals Tray', 'Cooked Meals', 'Rice, dal, mixed vegetable curry and curd.', 20, 'trays', 80, 80, -2, 8, 'Kukatpally', 'Vegetarian', 'Keep covered. Do not reheat more than once.'),
    pkg('P-003', 'D-003', 'Wedding Buffet Surplus', 'Cooked Meals', 'Pulao, paneer curry, rotis and sweets from a reception.', 50, 'kg', 200, 140, -4, 4, 'Secunderabad', 'Vegetarian', 'Event food - serve quickly. Sweets contain milk.'),
    pkg('P-004', 'D-005', 'Assorted Bread Loaves', 'Bakery & Bread', 'Sandwich bread and buns baked this morning.', 60, 'loaves', 60, 30, -6, 30, 'Gachibowli', 'Vegetarian', 'Store in a dry place.'),
    pkg('P-005', 'D-007', 'Fresh Vegetables Crate', 'Fruits & Vegetables', 'Tomato, onion, beans and gourds. Slightly cosmetic damage.', 80, 'kg', 200, 150, -5, 72, 'LB Nagar', 'Vegan', 'Wash before cooking.'),
    pkg('P-006', 'D-007', 'Seasonal Fruits', 'Fruits & Vegetables', 'Bananas, papaya and guava.', 36, 'kg', 90, 90, -5, 48, 'LB Nagar', 'Vegan', 'Keep away from direct heat.'),
    pkg('P-007', 'D-006', 'Biscuits & Snack Packs', 'Packaged Food', 'Sealed biscuit and namkeen packets, near best-before date.', 40, 'boxes', 100, 100, -24, 200, 'Ameerpet', 'Vegetarian', 'Check seals before distribution.'),
    pkg('P-008', 'D-006', 'Milk Packets (500 ml)', 'Dairy & Beverages', 'Pasteurised toned milk, refrigerated.', 35, 'litres', 70, 70, -10, 20, 'Ameerpet', 'Vegetarian', 'Keep refrigerated at 4°C.'),
    pkg('P-009', 'D-004', 'Rice & Dal Sacks', 'Grains & Staples', 'Unopened 5 kg rice bags and 2 kg dal packs.', 88, 'kg', 220, 100, -48, 400, 'Madhapur', 'Vegetarian', 'Dry storage only.'),
    pkg('P-010', 'D-006', 'Idli-Sambar Breakfast', 'Cooked Meals', 'Idli with sambar and chutney from the morning canteen.', 22, 'kg', 90, 0, -30, -20, 'Ameerpet', 'Vegetarian', 'Fully distributed.'),
    pkg('P-011', 'D-008', 'Temple Khichdi', 'Cooked Meals', 'Khichdi prepared for a temple festival.', 40, 'kg', 100, 0, -56, -44, 'Uppal', 'Vegetarian', 'Fully distributed.'),
    pkg('P-012', 'D-005', 'Pastries & Buns', 'Bakery & Bread', 'Day-old pastries.', 12, 'boxes', 40, 0, -40, -10, 'Gachibowli', 'Vegetarian', 'Fully distributed.'),
  ]

  const req = (id, ngoId, category, quantity, beneficiaries, neededH, location, urgency, reason, status, createdH) => ({
    id, ngoId, category, quantity, beneficiaries, neededBy: iso(neededH), location, urgency, reason, status, createdAt: iso(createdH),
  })
  const requests = [
    req('R-1001', 'N-001', 'Cooked Meals', 60, 60, 6, 'Ameerpet', 'Critical', 'Flood relief shelter needs dinner for displaced families.', 'In Transit', -5),
    req('R-1002', 'N-002', 'Cooked Meals', 60, 90, 5, 'Secunderabad', 'High', 'Night shelter dinner for daily wage workers.', 'Assigned', -4),
    req('R-1003', 'N-003', 'Grains & Staples', 60, 80, 30, 'Kukatpally', 'Medium', 'Replenish community kitchen stock for the week.', 'Assigned', -20),
    req('R-1004', 'N-004', 'Bakery & Bread', 30, 120, 20, 'Banjara Hills', 'Low', 'Breakfast for orphanage children.', 'Assigned', -16),
    req('R-1005', 'N-005', 'Cooked Meals', 90, 90, 9, 'Madhapur', 'High', 'Street-side meal drive for night-shift sanitation workers.', 'Pending', -2),
    req('R-1006', 'N-007', 'Fruits & Vegetables', 100, 120, 30, 'LB Nagar', 'Medium', 'Weekly nutrition support for families in the area.', 'Approved', -12),
    req('R-1007', 'N-006', 'Dairy & Beverages', 50, 60, 14, 'Uppal', 'High', 'Milk for toddlers and elderly residents.', 'Pending', -3),
    req('R-1008', 'N-008', 'Packaged Food', 80, 45, 120, 'Gachibowli', 'Low', 'Stock for old-age home snack time.', 'Pending', -30),
    req('R-1009', 'N-001', 'Grains & Staples', 500, 450, 60, 'Ameerpet', 'Medium', 'Bulk grain stock for monthly kitchen.', 'Rejected', -40),
    req('R-1010', 'N-002', 'Cooked Meals', 120, 200, 3, 'Secunderabad', 'Critical', 'Community kitchen ran out of food; 200 people waiting.', 'Pending', -1),
    req('R-1011', 'N-001', 'Cooked Meals', 60, 60, -22, 'Ameerpet', 'High', 'Breakfast for shelter residents.', 'Delivered', -40),
    req('R-1012', 'N-005', 'Cooked Meals', 30, 30, -21, 'Madhapur', 'Medium', 'Morning meal for sanitation workers.', 'Delivered', -38),
    req('R-1013', 'N-007', 'Cooked Meals', 100, 110, -46, 'LB Nagar', 'High', 'Festival-day community meal.', 'Delivered', -70),
    req('R-1014', 'N-004', 'Bakery & Bread', 40, 120, -12, 'Banjara Hills', 'Low', 'Snacks for orphanage children.', 'Delivered', -34),
    req('R-1015', 'N-003', 'Grains & Staples', 60, 80, -50, 'Kukatpally', 'Medium', 'Dry ration support.', 'Delivered', -80),
    req('R-1016', 'N-007', 'Fruits & Vegetables', 50, 70, -30, 'LB Nagar', 'Medium', 'Vegetables for community kitchen.', 'Delivered', -60),
  ]

  const asg = (id, packageId, requestId, servings, pickupH, volunteerId, status) => {
    const p = packages.find((x) => x.id === packageId)
    const r = requests.find((x) => x.id === requestId)
    const n = ngos.find((x) => x.id === r.ngoId)
    return {
      id, packageId, requestId, donorId: p.donorId, ngoId: r.ngoId, servings,
      pickupLocation: p.location, destination: `${n.name}, ${n.address}`,
      pickupAt: iso(pickupH), volunteerId, status, createdAt: iso(pickupH - 2),
      deliveredAt: status === 'Delivered' ? iso(pickupH + 2) : null,
    }
  }
  const assignments = [
    asg('A-5001', 'P-001', 'R-1001', 60, -1, 'V-01', 'In Transit'),
    asg('A-5002', 'P-003', 'R-1002', 60, 0.5, 'V-02', 'Picked Up'),
    asg('A-5003', 'P-009', 'R-1003', 60, 10, 'V-03', 'Assigned'),
    asg('A-5004', 'P-004', 'R-1004', 30, 6, 'V-04', 'Assigned'),
    asg('A-4001', 'P-010', 'R-1011', 60, -24, 'V-01', 'Delivered'),
    asg('A-4002', 'P-010', 'R-1012', 30, -23, 'V-04', 'Delivered'),
    asg('A-4003', 'P-011', 'R-1013', 100, -48, 'V-05', 'Delivered'),
    asg('A-4004', 'P-012', 'R-1014', 40, -14, 'V-04', 'Delivered'),
    asg('A-4005', 'P-009', 'R-1015', 60, -52, 'V-03', 'Delivered'),
    asg('A-4006', 'P-005', 'R-1016', 50, -32, 'V-05', 'Delivered'),
  ]

  const distributions = assignments
    .filter((a) => a.status === 'Delivered')
    .map((a, i) => ({
      id: `H-${9001 + i}`, assignmentId: a.id, packageId: a.packageId, donorId: a.donorId, ngoId: a.ngoId,
      servings: a.servings, mealsServed: a.servings, deliveredAt: a.deliveredAt, status: 'Completed',
    }))

  const notifications = [
    { id: 'NT-1', type: 'request', title: 'New request received', message: 'Asha Kiran Trust requested 120 Cooked Meals (Critical).', createdAt: iso(-1), read: false },
    { id: 'NT-2', type: 'expiry', title: 'Package expiring soon', message: 'Wedding Buffet Surplus expires in about 4 hours.', createdAt: iso(-1.5), read: false },
    { id: 'NT-3', type: 'assignment', title: 'Assignment update', message: 'A-5001 is now In Transit to Hope Foundation Hyderabad.', createdAt: iso(-2), read: false },
    { id: 'NT-4', type: 'approved', title: 'Request approved', message: 'R-1006 from Care & Share Society was approved.', createdAt: iso(-8), read: true },
    { id: 'NT-5', type: 'delivered', title: 'Delivery completed', message: '40 servings of Pastries & Buns reached Little Hands Orphanage.', createdAt: iso(-12), read: true },
  ]

  // 30 days of daily activity (before today) and 14 days of demand history for the prediction demo.
  const rnd = seeded(42)
  const activityHistory = Array.from({ length: 30 }, (_, i) => {
    const daysAgo = 30 - i
    const donations = Math.round(8 + rnd() * 10 + (daysAgo % 7 === 5 || daysAgo % 7 === 6 ? 5 : 0))
    return { date: dayStr(daysAgo), donations, meals: Math.round(donations * (22 + rnd() * 14)) }
  })

  const weekdayFactor = [0.9, 0.85, 0.9, 0.95, 1.05, 1.3, 1.2] // Sun..Sat
  const catShare = [0.34, 0.12, 0.17, 0.12, 0.1, 0.15]
  const locShare = [0.16, 0.08, 0.1, 0.13, 0.12, 0.14, 0.15, 0.12]
  const demandHistory = Array.from({ length: 14 }, (_, i) => {
    const daysAgo = 14 - i
    const date = dayStr(daysAgo)
    const meals = Math.round(300 * weekdayFactor[new Date(date).getUTCDay()] * (0.92 + rnd() * 0.16))
    return {
      date, meals,
      categories: Object.fromEntries(CATEGORIES.map((c, k) => [c, Math.round(meals * catShare[k])])),
      locations: Object.fromEntries(LOCATIONS.map((l, k) => [l, Math.round(meals * locShare[k])])),
    }
  })

  // Older months (before the live records above). Months are labelled dynamically in calculations.js.
  const monthlyHistory = [
    { donations: 118, distributedMeals: 3950 },
    { donations: 132, distributedMeals: 4410 },
    { donations: 149, distributedMeals: 5020 },
    { donations: 161, distributedMeals: 5480 },
    { donations: 174, distributedMeals: 5890 },
    { donations: 96, distributedMeals: 3120 }, // current month so far, before live records
  ]

  return {
    users, donors, ngos, volunteers, packages, requests, assignments, distributions,
    notifications, activityHistory, demandHistory, monthlyHistory,
    settings: { appName: 'FoodBridge', notifyEmail: true, notifyExpiry: true, notifyAssignments: true, notifyDigest: false, pageSize: 8, expiryWindowHours: 6 },
  }
}
