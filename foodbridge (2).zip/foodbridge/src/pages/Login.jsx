import { useState } from 'react'
import { Eye, EyeOff, Leaf, ShieldAlert } from 'lucide-react'
import { useApp } from '../context/AppContext'
import { ROLES } from '../data/constants'
import useForm from '../hooks/useForm'
import { SelectField, TextField, emailOk } from '../components/forms/Fields'

const DEMO = [
  { role: 'Admin', email: 'admin@foodbridge.demo', password: 'Admin@123' },
  { role: 'Donor', email: 'donor@foodbridge.demo', password: 'Donor@123' },
  { role: 'NGO', email: 'ngo@foodbridge.demo', password: 'Ngo@1234' },
  { role: 'Volunteer', email: 'volunteer@foodbridge.demo', password: 'Volunteer@1' },
]

function PasswordField({ label, value, onChange, error, autoComplete }) {
  const [show, setShow] = useState(false)
  return (
    <div className="pw-wrap">
      <TextField label={label} type={show ? 'text' : 'password'} required value={value} onChange={onChange} error={error} autoComplete={autoComplete} />
      <button type="button" className="icon-btn pw-toggle" onClick={() => setShow(!show)} aria-label={show ? 'Hide password' : 'Show password'}>
        {show ? <EyeOff size={18} /> : <Eye size={18} />}
      </button>
    </div>
  )
}

function SignIn({ onDone }) {
  const { login } = useApp()
  const [serverError, setServerError] = useState('')
  const f = useForm({ email: '', password: '' }, (v) => ({
    email: !v.email.trim() ? 'Enter your email.' : !emailOk(v.email) ? 'Enter a valid email like name@example.com.' : '',
    password: !v.password && 'Enter your password.',
  }))
  const submit = async (v) => {
    setServerError('')
    try { await login(v.email, v.password); onDone?.() } catch (e) { setServerError(e.message) }
  }
  const demoLogin = async (d) => {
    setServerError('')
    try { await login(d.email, d.password) } catch (e) { setServerError(e.message) }
  }
  return (
    <>
      <form onSubmit={f.handleSubmit(submit)} noValidate>
        <TextField label="Email" type="email" required autoComplete="email" value={f.values.email} onChange={f.bind('email')} error={f.errors.email} />
        <PasswordField label="Password" autoComplete="current-password" value={f.values.password} onChange={f.bind('password')} error={f.errors.password} />
        {serverError && <p className="field-error" role="alert">{serverError}</p>}
        <button className="btn btn-primary btn-block" type="submit" disabled={f.saving}>{f.saving ? 'Signing in...' : 'Sign in'}</button>
      </form>
      <div className="demo-box">
        <p><strong>Try the demo</strong> - sign in as:</p>
        <div className="demo-buttons">
          {DEMO.map((d) => <button key={d.role} className="btn btn-secondary btn-sm" onClick={() => demoLogin(d)}>{d.role}</button>)}
        </div>
        <table className="demo-table">
          <tbody>{DEMO.map((d) => <tr key={d.role}><th scope="row">{d.role}</th><td>{d.email}</td><td>{d.password}</td></tr>)}</tbody>
        </table>
      </div>
    </>
  )
}

function Register() {
  const { register } = useApp()
  const [serverError, setServerError] = useState('')
  const f = useForm({ name: '', email: '', password: '', role: 'Donor', organization: '', phone: '' }, (v) => ({
    name: !v.name.trim() && 'Enter your full name.',
    email: !v.email.trim() ? 'Enter your email.' : !emailOk(v.email) ? 'Enter a valid email like name@example.com.' : '',
    password: v.password.length < 8 ? 'Use at least 8 characters.' : '',
    organization: v.role === 'NGO' && !v.organization.trim() && 'Enter your NGO name.',
  }))
  const submit = async (v) => {
    setServerError('')
    try { await register(v) } catch (e) { setServerError(e.message) }
  }
  return (
    <form onSubmit={f.handleSubmit(submit)} noValidate>
      <TextField label="Full name" required value={f.values.name} onChange={f.bind('name')} error={f.errors.name} autoComplete="name" />
      <TextField label="Email" type="email" required value={f.values.email} onChange={f.bind('email')} error={f.errors.email} autoComplete="email" />
      <PasswordField label="Password" autoComplete="new-password" value={f.values.password} onChange={f.bind('password')} error={f.errors.password} />
      <SelectField label="I am joining as" options={ROLES} value={f.values.role} onChange={f.bind('role')} />
      {f.values.role !== 'Admin' && f.values.role !== 'Volunteer' && (
        <TextField label={f.values.role === 'NGO' ? 'NGO name' : 'Organisation (optional)'} required={f.values.role === 'NGO'} value={f.values.organization} onChange={f.bind('organization')} error={f.errors.organization} />
      )}
      <TextField label="Phone (optional)" value={f.values.phone} onChange={f.bind('phone')} />
      {serverError && <p className="field-error" role="alert">{serverError}</p>}
      <button className="btn btn-primary btn-block" type="submit" disabled={f.saving}>{f.saving ? 'Creating account...' : 'Create account'}</button>
      <p className="muted small">New NGO accounts start as “Pending” verification until an admin approves them.</p>
    </form>
  )
}

export default function Login() {
  const [tab, setTab] = useState('signin')
  return (
    <div className="auth">
      <section className="auth-hero">
        <div className="brand brand-light"><span className="brand-mark"><Leaf size={20} /></span><span className="brand-name">FoodBridge</span></div>
        <h1>Surplus food, delivered to people who need it.</h1>
        <p>List surplus meals, match them with NGO requests, and track every delivery from pickup to plate.</p>
        <ul className="auth-points">
          <li>Donors list packages in under a minute</li>
          <li>NGOs see urgent needs ranked by priority</li>
          <li>Volunteers update pickups and deliveries on the go</li>
        </ul>
      </section>
      <section className="auth-panel">
        <div className="auth-card">
          <div className="segmented segmented-wide" role="tablist">
            <button role="tab" aria-selected={tab === 'signin'} className={tab === 'signin' ? 'on' : ''} onClick={() => setTab('signin')}>Sign in</button>
            <button role="tab" aria-selected={tab === 'register'} className={tab === 'register' ? 'on' : ''} onClick={() => setTab('register')}>Create account</button>
          </div>
          <h2>{tab === 'signin' ? 'Welcome back' : 'Join FoodBridge'}</h2>
          {tab === 'signin' ? <SignIn /> : <Register />}
          <p className="demo-warning"><ShieldAlert size={15} /> Demo authentication only. Passwords are stored in your browser and are not secure.</p>
        </div>
      </section>
    </div>
  )
}
