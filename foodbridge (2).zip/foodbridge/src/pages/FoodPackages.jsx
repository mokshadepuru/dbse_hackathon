import { useEffect, useMemo, useState } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { Clock, Download, HandHeart, LayoutGrid, MapPin, Pencil, Plus, Table2, Timer, Trash2 } from 'lucide-react'
import { useApp } from '../context/AppContext'
import PageHeader from '../components/common/PageHeader'
import DataTable from '../components/common/DataTable'
import Badge from '../components/common/Badge'
import Modal from '../components/common/Modal'
import ConfirmDialog from '../components/common/ConfirmDialog'
import CategoryIcon from '../components/common/CategoryIcon'
import { EmptyState } from '../components/common/States'
import { SearchBox, SelectFilter } from '../components/common/FilterBar'
import PackageForm from '../components/forms/PackageForm'
import RequestForm from '../components/forms/RequestForm'
import { CATEGORIES, LOCATIONS } from '../data/constants'
import { byId, fmtDateTime, hoursUntil, isExpiringSoon, isRequestable, packageStatus, timeLeft } from '../utils/calculations'
import { exportCsv } from '../utils/csvExport'

export default function FoodPackages() {
  const { db, user, can, addPackage, updatePackage, deletePackage, addRequest } = useApp()
  const [params, setParams] = useSearchParams()
  const nav = useNavigate()
  const [view, setView] = useState('cards')
  const [q, setQ] = useState(params.get('q') || '')
  const [category, setCategory] = useState('')
  const [location, setLocation] = useState('')
  const [availability, setAvailability] = useState('')
  const [expiry, setExpiry] = useState('')
  const [sort, setSort] = useState('expiry')
  const [modal, setModal] = useState(null) // { mode: 'add' | 'edit' | 'request', pkg }
  const [confirm, setConfirm] = useState(null)

  // Dashboard "Add donation" button links here with ?new=1
  useEffect(() => {
    if (params.get('new') && can('addPackage')) {
      setModal({ mode: 'add' })
      setParams({}, { replace: true })
    }
  }, [params, can, setParams])

  const donors = useMemo(() => byId(db.donors), [db.donors])
  const win = db.settings.expiryWindowHours

  const filtered = useMemo(() => {
    const t = q.trim().toLowerCase()
    const list = db.packages.filter((p) => {
      const status = packageStatus(p)
      return (!t || `${p.id} ${p.name} ${p.description} ${donors[p.donorId]?.organization}`.toLowerCase().includes(t))
        && (!category || p.category === category) && (!location || p.location === location)
        && (!availability || status === availability)
        && (!expiry || (expiry === 'soon' ? isExpiringSoon(p, win) : expiry === 'day' ? status === 'Available' && hoursUntil(p.expiresAt) <= 24 : status === 'Available' && hoursUntil(p.expiresAt) > 24))
    })
    const order = {
      expiry: (a, b) => new Date(a.expiresAt) - new Date(b.expiresAt),
      servings: (a, b) => b.availableServings - a.availableServings,
      newest: (a, b) => new Date(b.createdAt) - new Date(a.createdAt),
    }
    // available packages first, then by the chosen sort
    return list.sort((a, b) => Number(isRequestable(b)) - Number(isRequestable(a)) || order[sort](a, b))
  }, [db.packages, donors, q, category, location, availability, expiry, sort, win])

  const donorLocked = user.role === 'Donor' ? user.linkedId : undefined
  const savePkg = async (values) => {
    const ok = modal.mode === 'edit' ? await updatePackage(modal.pkg.id, values) : await addPackage(values)
    if (ok) setModal(null)
  }
  const saveRequest = async (values) => {
    if (await addRequest(values)) {
      setModal(null)
      nav('/requests')
    }
  }
  const doDelete = async () => {
    await deletePackage(confirm.id)
    setConfirm(null)
  }

  const StatusBadge = ({ p }) => {
    const s = packageStatus(p)
    return s === 'Available' && isExpiringSoon(p, win) ? <Badge tone="amber">Expiring soon</Badge> : <Badge>{s}</Badge>
  }

  const actions = (p) => (
    <div className="row-actions">
      {can('createRequest') && (
        <button className="btn btn-primary btn-sm" disabled={!isRequestable(p)} title={isRequestable(p) ? '' : 'This package is not available'} onClick={() => setModal({ mode: 'request', pkg: p })}>
          <HandHeart size={14} /> Request
        </button>
      )}
      {can('editPackage') && (
        <>
          <button className="icon-btn" aria-label={`Edit ${p.name}`} onClick={() => setModal({ mode: 'edit', pkg: p })}><Pencil size={16} /></button>
          <button className="icon-btn danger" aria-label={`Delete ${p.name}`} onClick={() => setConfirm(p)}><Trash2 size={16} /></button>
        </>
      )}
    </div>
  )

  const columns = [
    { key: 'name', header: 'Package', render: (p) => <><strong>{p.name}</strong><div className="muted small">{p.id} - {p.category}</div></> },
    { key: 'donor', header: 'Donor', sortValue: (p) => donors[p.donorId]?.organization, render: (p) => donors[p.donorId]?.organization },
    { key: 'qty', header: 'Quantity', sortValue: (p) => p.quantity, render: (p) => `${p.quantity} ${p.unit}` },
    { key: 'availableServings', header: 'Servings left', sortValue: (p) => p.availableServings, render: (p) => `${p.availableServings} / ${p.servings}` },
    { key: 'location', header: 'Pickup' },
    { key: 'expiresAt', header: 'Expires', sortValue: (p) => new Date(p.expiresAt).getTime(), render: (p) => <>{fmtDateTime(p.expiresAt)}<div className="muted small">{timeLeft(p.expiresAt)}</div></> },
    { key: 'status', header: 'Status', sortValue: (p) => packageStatus(p), render: (p) => <StatusBadge p={p} /> },
    { key: 'actions', header: '', sortable: false, className: 'actions', render: actions },
  ]

  const csvColumns = [
    { header: 'ID', value: (p) => p.id }, { header: 'Package', value: (p) => p.name }, { header: 'Category', value: (p) => p.category },
    { header: 'Donor', value: (p) => donors[p.donorId]?.organization }, { header: 'Quantity', value: (p) => `${p.quantity} ${p.unit}` },
    { header: 'Total servings', value: (p) => p.servings }, { header: 'Servings left', value: (p) => p.availableServings },
    { header: 'Pickup location', value: (p) => p.location }, { header: 'Expires', value: (p) => p.expiresAt }, { header: 'Status', value: (p) => packageStatus(p) },
  ]

  const requestNgos = user.role === 'NGO' ? db.ngos.filter((n) => n.id === user.linkedId) : db.ngos

  return (
    <>
      <PageHeader title="Food packages" subtitle="Surplus food listed by donors. Packages that expire soon are shown first."
        actions={<>
          <button className="btn btn-secondary" onClick={() => exportCsv('foodbridge-packages.csv', csvColumns, filtered)}><Download size={16} /> Export CSV</button>
          {can('addPackage') && <button className="btn btn-primary" onClick={() => setModal({ mode: 'add' })}><Plus size={16} /> Add package</button>}
        </>} />

      <div className="card">
        <div className="toolbar">
          <SearchBox value={q} onChange={setQ} placeholder="Search packages or donors" label="Search packages" />
          <SelectFilter label="Categories" value={category} onChange={setCategory} options={CATEGORIES} />
          <SelectFilter label="Locations" value={location} onChange={setLocation} options={LOCATIONS} />
          <SelectFilter label="Availability" value={availability} onChange={setAvailability} options={['Available', 'Fully assigned', 'Expired']} allLabel="Any availability" />
          <SelectFilter label="Expiry" value={expiry} onChange={setExpiry} allLabel="Any expiry"
            options={[{ value: 'soon', label: `Expiring within ${win} h` }, { value: 'day', label: 'Within 24 h' }, { value: 'later', label: 'More than 24 h' }]} />
          <label className="select-filter">
            <span className="sr-only">Sort packages</span>
            <select value={sort} onChange={(e) => setSort(e.target.value)} aria-label="Sort packages">
              <option value="expiry">Sort: expiring first</option>
              <option value="servings">Sort: most servings</option>
              <option value="newest">Sort: newest</option>
            </select>
          </label>
          <div className="segmented" role="group" aria-label="View mode">
            <button className={view === 'cards' ? 'on' : ''} onClick={() => setView('cards')} aria-pressed={view === 'cards'}><LayoutGrid size={15} /> Cards</button>
            <button className={view === 'table' ? 'on' : ''} onClick={() => setView('table')} aria-pressed={view === 'table'}><Table2 size={15} /> Table</button>
          </div>
        </div>

        {filtered.length === 0 ? (
          <EmptyState title="No food packages match" message="Try clearing filters, or list a new package." />
        ) : view === 'table' ? (
          <DataTable columns={columns} rows={filtered} pageSize={db.settings.pageSize} caption="Food packages" />
        ) : (
          <div className="pkg-grid">
            {filtered.map((p) => {
              const soon = isExpiringSoon(p, win)
              const donor = donors[p.donorId]
              return (
                <article key={p.id} className={`pkg-card ${soon ? 'pkg-soon' : ''} ${isRequestable(p) ? '' : 'pkg-off'}`}>
                  <div className="pkg-top">
                    <span className="pkg-icon"><CategoryIcon category={p.category} /></span>
                    <StatusBadge p={p} />
                  </div>
                  <h3>{p.name}</h3>
                  <p className="muted small">{p.id} - {donor?.organization}</p>
                  <p className="pkg-desc">{p.description}</p>
                  <div className="pkg-tags">
                    <Badge>{p.diet}</Badge>
                    <span className="tag">{p.category}</span>
                  </div>
                  <dl className="pkg-meta">
                    <div><dt>Quantity</dt><dd>{p.quantity} {p.unit}</dd></div>
                    <div><dt>Servings left</dt><dd>{p.availableServings} / {p.servings}</dd></div>
                    <div><dt><MapPin size={12} /> Pickup</dt><dd>{p.location}</dd></div>
                    <div className={soon ? 'warn' : ''}><dt>{soon ? <Timer size={12} /> : <Clock size={12} />} Expires</dt><dd>{timeLeft(p.expiresAt)}</dd></div>
                  </dl>
                  {p.notes && <p className="pkg-note">Handling: {p.notes}</p>}
                  <div className="pkg-foot">{actions(p)}</div>
                </article>
              )
            })}
          </div>
        )}
      </div>

      {modal && modal.mode !== 'request' && (
        <Modal title={modal.mode === 'edit' ? 'Edit food package' : 'List a food package'} size="lg" onClose={() => setModal(null)}>
          <PackageForm pkg={modal.pkg} donors={db.donors.filter((d) => d.status === 'Active' || d.id === modal.pkg?.donorId)} fixedDonorId={donorLocked}
            assignedServings={modal.pkg ? modal.pkg.servings - modal.pkg.availableServings : 0} onSubmit={savePkg} onCancel={() => setModal(null)} />
        </Modal>
      )}
      {modal?.mode === 'request' && (
        <Modal title={`Request ${modal.pkg.name}`} size="lg" onClose={() => setModal(null)}>
          <p className="muted info-line">Creating a request for {modal.pkg.category} near {modal.pkg.location}. An admin will review it and assign food.</p>
          <RequestForm ngos={requestNgos} fixedNgoId={user.role === 'NGO' ? user.linkedId : undefined}
            initial={{ category: modal.pkg.category, location: modal.pkg.location, quantity: Math.min(modal.pkg.availableServings, 50) }} onSubmit={saveRequest} onCancel={() => setModal(null)} />
        </Modal>
      )}
      {confirm && (
        <ConfirmDialog title="Delete this package?" message={`“${confirm.name}” will be removed from inventory. Packages that already have assignments cannot be deleted.`}
          confirmLabel="Delete package" onConfirm={doDelete} onCancel={() => setConfirm(null)} />
      )}
    </>
  )
}
