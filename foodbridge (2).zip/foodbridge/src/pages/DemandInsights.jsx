import { useCallback, useEffect, useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { AlertTriangle, ArrowRight, BrainCircuit, CheckCircle2, Info, MapPin, RefreshCw, TrendingUp } from 'lucide-react'
import { useApp } from '../context/AppContext'
import PageHeader from '../components/common/PageHeader'
import StatCard from '../components/common/StatCard'
import Badge from '../components/common/Badge'
import Modal from '../components/common/Modal'
import ChartCard from '../components/charts/ChartCard'
import { ForecastLineChart, HorizontalBars } from '../components/charts/Charts'
import { ErrorState, Loading } from '../components/common/States'
import { predictionService } from '../services/predictionService'
import { API_BASE_URL } from '../services/api'
import { byId, fmtNumber, timeLeft } from '../utils/calculations'

const SOURCE_TEXT = {
  demo: 'Demo mode: predictions are calculated in your browser from the sample data.',
  api: `Live data from the prediction API at ${API_BASE_URL}.`,
  'demo-fallback': 'The prediction API could not be reached, so demo data is shown instead.',
}

export default function DemandInsights() {
  const { db, can, toast } = useApp()
  const nav = useNavigate()
  const [state, setState] = useState({ demand: null, priorities: null })
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const [error, setError] = useState('')
  const [explain, setExplain] = useState(null)

  const load = useCallback(async (manual) => {
    manual ? setRefreshing(true) : setLoading(true)
    setError('')
    try {
      const result = manual ? await predictionService.refresh(db)
        : { demand: await predictionService.getDemand(db), priorities: await predictionService.getPriorities(db) }
      setState(result)
      if (manual) toast('success', 'Predictions refreshed using the latest inventory and requests.')
    } catch (e) {
      setError(e.message || 'Could not calculate predictions.')
      if (manual) toast('error', 'Refreshing predictions failed.')
    } finally {
      setLoading(false)
      setRefreshing(false)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [db.packages, db.requests, db.ngos])

  // Recalculate when inventory or requests change, so recommendations always use current data.
  useEffect(() => { load(false) }, [load])

  const requests = useMemo(() => byId(db.requests), [db.requests])
  const ngos = useMemo(() => byId(db.ngos), [db.ngos])
  const pkgs = useMemo(() => byId(db.packages), [db.packages])

  if (loading && !state.demand) return <Loading label="Calculating demand predictions..." />
  if (error && !state.demand) return <ErrorState message={error} onRetry={() => load(false)} />
  const { demand, priorities } = state
  if (!demand || !priorities) return null

  const source = demand.source
  const lastHistory = [...demand.chart].reverse().find((p) => p.actual !== undefined)
  const topCat = demand.byCategory[0]
  const topLoc = demand.byLocation[0]

  return (
    <>
      <PageHeader title="AI & demand insights" subtitle="Forecasts and request priorities to help decide where food should go first."
        actions={<button className="btn btn-primary" onClick={() => load(true)} disabled={refreshing}><RefreshCw size={16} className={refreshing ? 'spin' : ''} /> {refreshing ? 'Refreshing...' : 'Refresh predictions'}</button>} />

      <div className="banner banner-demo" role="note">
        <Info size={18} />
        <div>
          <strong>Demo prediction, not a trained machine-learning model.</strong> Numbers come from a transparent formula using sample history, request urgency, beneficiaries, time left and current inventory.
          <div className="small">{SOURCE_TEXT[source] || SOURCE_TEXT.demo}</div>
        </div>
      </div>
      {source === 'demo-fallback' && <div className="banner banner-urgent" role="alert"><AlertTriangle size={18} /> Prediction API unavailable. Check that the backend is running and VITE_API_URL is correct.</div>}
      {!refreshing && !error && state.demand && <p className="sr-only" role="status">Predictions are up to date.</p>}

      <div className="grid grid-4">
        <StatCard icon={TrendingUp} label="Predicted demand, next 7 days" value={`${fmtNumber(demand.total)} meals`} hint="Demo forecast" />
        <StatCard icon={BrainCircuit} label="Highest-demand category" value={topCat.name} hint={`${fmtNumber(topCat.predicted)} meals`} tone="blue" />
        <StatCard icon={MapPin} label="Highest-demand area" value={topLoc.name} hint={`${fmtNumber(topLoc.predicted)} meals`} tone="amber" />
        <StatCard icon={CheckCircle2} label="Requests ranked" value={priorities.priorities.length} hint="Pending and approved" />
      </div>

      <div className="mt">
        <ChartCard title="Historical vs predicted demand" subtitle="Meals requested per day: last 14 days and the next 7 days" height={300}>
          <ForecastLineChart data={demand.chart} splitLabel={lastHistory?.label} />
        </ChartCard>
      </div>

      <div className="grid grid-2 mt">
        <ChartCard title="Predicted demand by category" subtitle="Next 7 days, in meals" height={280}><HorizontalBars data={demand.byCategory} /></ChartCard>
        <ChartCard title="Predicted demand by service area" subtitle="Next 7 days, in meals" height={280}><HorizontalBars data={demand.byLocation} color="#5FB487" /></ChartCard>
      </div>

      <section className="card mt">
        <div className="card-head"><h3>High-demand locations</h3><span className="muted small">Gap = predicted demand minus servings available there now</span></div>
        <div className="grid grid-3">
          {demand.highDemandLocations.map((l) => (
            <div key={l.name} className="loc-card">
              <strong><MapPin size={14} /> {l.name}</strong>
              <span>{fmtNumber(l.predicted)} meals predicted</span>
              <span className="muted small">{l.supply} servings available now</span>
              <Badge tone={l.gap > 0 ? 'amber' : 'green'}>{l.gap > 0 ? `Shortfall of ${l.gap}` : 'Covered'}</Badge>
            </div>
          ))}
        </div>
      </section>

      <section className="card mt">
        <div className="card-head"><h3>Requests ranked by priority</h3><span className="muted small">Score 0-100. Select a row to see why.</span></div>
        {priorities.priorities.length === 0 ? <p className="muted pad">No pending or approved requests to rank.</p> : (
          <div className="table-wrap">
            <table className="table">
              <thead><tr><th>Rank</th><th>Request</th><th>Need</th><th>Needed</th><th>Priority score</th><th></th></tr></thead>
              <tbody>
                {priorities.priorities.map((p, i) => {
                  const r = requests[p.requestId]
                  if (!r) return null
                  return (
                    <tr key={p.requestId}>
                      <td data-label="Rank"><strong>#{i + 1}</strong></td>
                      <td data-label="Request"><strong>{ngos[r.ngoId]?.name}</strong><div className="muted small">{r.id} - {r.location} - <Badge>{r.urgency}</Badge></div></td>
                      <td data-label="Need">{r.quantity} servings of {r.category}<div className="muted small">{r.beneficiaries} people</div></td>
                      <td data-label="Needed">{timeLeft(r.neededBy)}</td>
                      <td data-label="Priority score">
                        <div className="score"><div className="score-bar"><span className={`lvl-${p.level}`} style={{ width: `${p.score}%` }} /></div><strong>{p.score}</strong><Badge>{p.level}</Badge></div>
                      </td>
                      <td data-label=""><button className="btn btn-secondary btn-sm" onClick={() => setExplain(p)}>Why?</button></td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>

      <section className="card mt">
        <div className="card-head"><h3>Recommended donation-to-request matches</h3><span className="muted small">Highest priority first. Food is never promised twice.</span></div>
        {priorities.matches.length === 0 ? <p className="muted pad">Nothing to match right now.</p> : (
          <ul className="match-list">
            {priorities.matches.map((m) => {
              const r = requests[m.requestId]
              const p = m.packageId ? pkgs[m.packageId] : null
              if (!r) return null
              return (
                <li key={m.requestId} className={p ? '' : 'match-none'}>
                  <div>
                    <strong>{ngos[r.ngoId]?.name}</strong> <span className="muted small">needs {r.quantity} {r.category} - score {m.score}</span>
                    <div className="match-arrow">{p ? <><ArrowRight size={14} /> <strong>{m.servings} servings</strong> from {p.name} ({p.id}, {p.location})</> : <><AlertTriangle size={14} /> No match</>}</div>
                    <div className="muted small">{m.reason}</div>
                  </div>
                  {p && can('assign') && (
                    <button className="btn btn-primary btn-sm" onClick={() => nav(`/assignments?request=${r.id}&package=${p.id}&servings=${m.servings}`)}>Review and assign</button>
                  )}
                </li>
              )
            })}
          </ul>
        )}
      </section>

      <p className="muted small mt">{demand.method} Priority score = urgency (35) + beneficiaries (20) + time remaining (25) + matching food available (10) + food expiry (10).</p>

      {explain && (() => {
        const r = requests[explain.requestId]
        return (
          <Modal title={`Why is ${r.id} scored ${explain.score}?`} onClose={() => setExplain(null)} footer={<button className="btn btn-secondary" onClick={() => setExplain(null)}>Close</button>}>
            <p className="muted">{ngos[r.ngoId]?.name} - {r.quantity} servings of {r.category}. Each factor adds points up to its maximum.</p>
            <ul className="factors">
              {explain.factors.map((f) => (
                <li key={f.key}>
                  <div className="factor-top"><span>{f.label}</span><strong>{f.points} / {f.max}</strong></div>
                  <div className="score-bar"><span style={{ width: `${(f.points / f.max) * 100}%` }} className="lvl-High" /></div>
                  <span className="muted small">{f.detail}</span>
                </li>
              ))}
            </ul>
            <p className="info-line">Total {explain.score} / 100 = {explain.level} priority. This is a demo scoring formula, not a trained model.</p>
          </Modal>
        )
      })()}
    </>
  )
}
