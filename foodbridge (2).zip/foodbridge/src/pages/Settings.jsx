import { useState } from 'react'
import { LogOut, RotateCcw, ShieldAlert } from 'lucide-react'
import { useApp } from '../context/AppContext'
import PageHeader from '../components/common/PageHeader'
import Modal from '../components/common/Modal'
import ConfirmDialog from '../components/common/ConfirmDialog'
import Badge from '../components/common/Badge'
import DonorForm from '../components/forms/DonorForm'
import NgoForm from '../components/forms/NgoForm'
import useForm from '../hooks/useForm'
import { TextField, SelectField, emailOk } from '../components/forms/Fields'

function Toggle({ label, hint, checked, onChange }) {
  return (
    <label className="toggle-row">
      <span><strong>{label}</strong><span className="muted small">{hint}</span></span>
      <input type="checkbox" role="switch" checked={checked} onChange={(e) => onChange(e.target.checked)} />
    </label>
  )
}

export default function Settings() {
  const { db, user, updateProfile, saveSettings, resetDemo, logout, updateDonor, updateNgo, can } = useApp()
  const [prefs, setPrefs] = useState(db.settings)
  const [confirmReset, setConfirmReset] = useState(false)
  const [orgModal, setOrgModal] = useState(false)

  const f = useForm({ name: user.name, email: user.email }, (v) => ({
    name: !v.name.trim() && 'Enter your name.',
    email: !emailOk(v.email) && 'Enter a valid email like name@example.com.',
  }))

  const donor = user.role === 'Donor' ? db.donors.find((d) => d.id === user.linkedId) : null
  const ngo = user.role === 'NGO' ? db.ngos.find((n) => n.id === user.linkedId) : null
  const volunteer = user.role === 'Volunteer' ? db.volunteers.find((v) => v.id === user.linkedId) : null
  const org = donor || ngo
  const setPref = (k) => (v) => setPrefs((p) => ({ ...p, [k]: v }))

  return (
    <>
      <PageHeader title="Settings and profile" subtitle="Manage your profile, organisation details and preferences." />
      <div className="grid grid-2">
        <section className="card pad-card">
          <h3>Your profile</h3>
          <form onSubmit={f.handleSubmit((v) => updateProfile({ name: v.name.trim(), email: v.email.trim() }))} noValidate>
            <div className="profile-head"><span className="avatar avatar-lg">{user.name.charAt(0)}</span><div><strong>{user.name}</strong><div><Badge tone="green">{user.role}</Badge></div></div></div>
            <TextField label="Full name" required value={f.values.name} onChange={f.bind('name')} error={f.errors.name} />
            <TextField label="Email" type="email" required value={f.values.email} onChange={f.bind('email')} error={f.errors.email} />
            <p className="muted small">Profile changes are saved in this browser only. Account ID: {user.id}</p>
            <button type="submit" className="btn btn-primary">Save profile</button>
          </form>
        </section>

        <section className="card pad-card">
          <h3>Organisation details</h3>
          {org ? (
            <>
              <dl className="detail-grid">
                <div><dt>Name</dt><dd>{donor ? donor.organization : ngo.name}</dd></div>
                <div><dt>Contact</dt><dd>{donor ? donor.name : ngo.contactPerson}</dd></div>
                <div><dt>Phone</dt><dd>{org.phone || '-'}</dd></div>
                <div><dt>Email</dt><dd>{org.email}</dd></div>
                <div><dt>Area</dt><dd>{donor ? donor.location : ngo.serviceArea}</dd></div>
                <div><dt>{donor ? 'Status' : 'Verification'}</dt><dd><Badge>{donor ? donor.status : ngo.verification}</Badge></dd></div>
              </dl>
              <button className="btn btn-secondary" onClick={() => setOrgModal(true)}>Edit organisation details</button>
            </>
          ) : volunteer ? (
            <dl className="detail-grid">
              <div><dt>Name</dt><dd>{volunteer.name}</dd></div><div><dt>Vehicle</dt><dd>{volunteer.vehicle}</dd></div>
              <div><dt>Home area</dt><dd>{volunteer.area}</dd></div><div><dt>Phone</dt><dd>{volunteer.phone || '-'}</dd></div>
            </dl>
          ) : (
            <p className="muted">You are signed in as an administrator of FoodBridge. Manage donors and NGOs from their own pages.</p>
          )}
        </section>

        <section className="card pad-card">
          <h3>Notification preferences</h3>
          <Toggle label="Email notifications" hint="Receive updates by email" checked={prefs.notifyEmail} onChange={setPref('notifyEmail')} />
          <Toggle label="Expiry alerts" hint="Warn me when packages are about to expire" checked={prefs.notifyExpiry} onChange={setPref('notifyExpiry')} />
          <Toggle label="Assignment updates" hint="Pickup, transit and delivery changes" checked={prefs.notifyAssignments} onChange={setPref('notifyAssignments')} />
          <Toggle label="Daily digest" hint="One summary email each morning" checked={prefs.notifyDigest} onChange={setPref('notifyDigest')} />
          <p className="muted small">Preferences are stored now; a notification service would use them to decide what to send.</p>
        </section>

        <section className="card pad-card">
          <h3>Application settings</h3>
          <SelectField label="Rows per table page" value={prefs.pageSize} onChange={(e) => setPref('pageSize')(Number(e.target.value))} options={[5, 8, 12, 20]} />
          <SelectField label="“Expiring soon” window" value={prefs.expiryWindowHours} onChange={(e) => setPref('expiryWindowHours')(Number(e.target.value))}
            options={[3, 6, 12, 24].map((h) => ({ value: h, label: `${h} hours before expiry` }))} />
          <button className="btn btn-primary" onClick={() => saveSettings(prefs)}>Save settings</button>
        </section>
      </div>

      <section className="card pad-card mt">
        <h3>Session and demo data</h3>
        <div className="settings-actions">
          <div>
            <strong>Reset demo data</strong>
            <p className="muted small">Restores the original sample donors, NGOs, packages, requests and deliveries. Accounts you registered stay.</p>
            <button className="btn btn-danger" onClick={() => setConfirmReset(true)}><RotateCcw size={16} /> Reset demo data</button>
          </div>
          <div>
            <strong>Log out</strong>
            <p className="muted small">Return to the login screen.</p>
            <button className="btn btn-secondary" onClick={logout}><LogOut size={16} /> Log out</button>
          </div>
        </div>
        <p className="demo-warning"><ShieldAlert size={15} /> This prototype uses demo authentication and browser storage. It is not secure or production-ready.</p>
      </section>

      {orgModal && (
        <Modal title="Edit organisation details" size="lg" onClose={() => setOrgModal(false)}>
          {donor ? <DonorForm donor={donor} onSubmit={async (v) => { if (await updateDonor(donor.id, v)) setOrgModal(false) }} onCancel={() => setOrgModal(false)} />
            : <NgoForm ngo={ngo} canVerify={can('manageNgos')} onSubmit={async (v) => { if (await updateNgo(ngo.id, v)) setOrgModal(false) }} onCancel={() => setOrgModal(false)} />}
        </Modal>
      )}
      {confirmReset && (
        <ConfirmDialog title="Reset all demo data?" message="Everything you added or changed will be replaced by the original sample data." confirmLabel="Reset data"
          onConfirm={async () => { await resetDemo(); setPrefs((p) => ({ ...p, pageSize: 8, expiryWindowHours: 6, notifyEmail: true, notifyExpiry: true, notifyAssignments: true, notifyDigest: false })); setConfirmReset(false) }} onCancel={() => setConfirmReset(false)} />
      )}
    </>
  )
}
