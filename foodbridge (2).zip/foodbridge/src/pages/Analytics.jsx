import { useMemo, useState } from 'react'
import { Building2, CheckCircle2, Download, HeartHandshake, Leaf, Utensils } from 'lucide-react'
import { useApp } from '../context/AppContext'
import PageHeader from '../components/common/PageHeader'
import StatCard from '../components/common/StatCard'
import ChartCard, { RangeToggle } from '../components/charts/ChartCard'
import { DonutChart, MonthlyBarChart } from '../components/charts/Charts'
import { CHART_COLORS } from '../components/charts/ChartCard'
import DataTable from '../components/common/DataTable'
import { categoryDistribution, fmtNumber, monthlySeries } from '../utils/calculations'
import { exportCsv } from '../utils/csvExport'
import { REQUEST_STATUSES } from '../data/constants'

export default function Analytics() {
  const { db, metrics } = useApp()
  const [months, setMonths] = useState(6)

  const series = useMemo(() => monthlySeries(db).slice(-months), [db, months])
  const categories = useMemo(() => categoryDistribution(db).map((c, i) => ({ ...c, color: CHART_COLORS[i % CHART_COLORS.length] })), [db])
  const statusRows = REQUEST_STATUSES.map((s) => ({ id: s, status: s, count: db.requests.filter((r) => r.status === s).length }))

  const monthCols = [
    { key: 'month', header: 'Month' },
    { key: 'donations', header: 'Donations', sortValue: (r) => r.donations },
    { key: 'meals', header: 'Meals served', sortValue: (r) => r.meals, render: (r) => fmtNumber(r.meals) },
    { key: 'kg', header: 'Waste prevented (kg)', sortValue: (r) => r.kg, render: (r) => fmtNumber(r.kg) },
  ]
  const monthRows = series.map((r) => ({ ...r, id: r.month }))
  const total = categories.reduce((s, c) => s + c.value, 0) || 1

  return (
    <>
      <PageHeader title="Reports and analytics" subtitle="Older months are sample history. The current month also includes live records from this demo."
        actions={<RangeToggle value={months} onChange={setMonths} options={[{ value: 3, label: '3 months' }, { value: 6, label: '6 months' }]} />} />

      <div className="grid grid-3">
        <StatCard icon={Utensils} label="Meals served" value={fmtNumber(metrics.mealsDistributed)} />
        <StatCard icon={Leaf} label="Waste prevented" value={`${fmtNumber(metrics.wastePreventedKg)} kg`} hint="Estimated at 0.4 kg per meal" />
        <StatCard icon={CheckCircle2} label="Request completion rate" value={`${metrics.completionRate}%`} hint="Delivered of all non-rejected requests" tone="blue" />
        <StatCard icon={HeartHandshake} label="Active donors" value={metrics.activeDonors} hint={`${db.donors.length} registered`} />
        <StatCard icon={Building2} label="Verified NGOs" value={metrics.verifiedNgos} hint={`${db.ngos.length} registered`} tone="blue" />
        <StatCard icon={Leaf} label="Total donations" value={fmtNumber(metrics.totalDonations)} tone="amber" />
      </div>

      <div className="grid grid-2 mt">
        <ChartCard title="Donations by month" subtitle="Food packages listed"><MonthlyBarChart data={series} bars={[{ key: 'donations', name: 'Donations' }]} /></ChartCard>
        <ChartCard title="Food distributed by month" subtitle="Meals served and kilograms of food"><MonthlyBarChart data={series} bars={[{ key: 'meals', name: 'Meals served' }, { key: 'kg', name: 'Food (kg)', color: '#F59E0B' }]} /></ChartCard>
      </div>

      <div className="grid grid-2 mt">
        <ChartCard title="Donations by category" subtitle="Share of servings listed"><DonutChart data={categories} /></ChartCard>
        <section className="card">
          <div className="card-head">
            <h3>Category breakdown</h3>
            <button className="btn btn-secondary btn-sm" onClick={() => exportCsv('foodbridge-categories.csv', [{ header: 'Category', value: (r) => r.name }, { header: 'Servings listed', value: (r) => r.value }, { header: 'Share %', value: (r) => Math.round((r.value / total) * 100) }], categories)}><Download size={14} /> CSV</button>
          </div>
          <ul className="bar-list">
            {categories.map((c) => (
              <li key={c.name}><span>{c.name}</span><div className="score-bar"><span style={{ width: `${(c.value / total) * 100}%`, background: c.color }} /></div><strong>{Math.round((c.value / total) * 100)}%</strong></li>
            ))}
          </ul>
          <h4 className="mt">Requests by status</h4>
          <ul className="bar-list">
            {statusRows.map((s) => (
              <li key={s.status}><span>{s.status}</span><div className="score-bar"><span style={{ width: `${(s.count / db.requests.length) * 100}%` }} /></div><strong>{s.count}</strong></li>
            ))}
          </ul>
        </section>
      </div>

      <section className="card mt">
        <div className="card-head">
          <h3>Monthly summary</h3>
          <button className="btn btn-secondary btn-sm" onClick={() => exportCsv('foodbridge-monthly-summary.csv', [
            { header: 'Month', value: (r) => r.month }, { header: 'Donations', value: (r) => r.donations }, { header: 'Meals served', value: (r) => r.meals }, { header: 'Waste prevented (kg)', value: (r) => r.kg },
          ], monthRows)}><Download size={14} /> Export CSV</button>
        </div>
        <DataTable columns={monthCols} rows={monthRows} pageSize={12} caption="Monthly summary" />
      </section>
    </>
  )
}
