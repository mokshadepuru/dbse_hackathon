import { useEffect, useMemo, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { ArrowRight, Download, Plus, Undo2 } from 'lucide-react'
import { useApp } from '../context/AppContext'
import PageHeader from '../components/common/PageHeader'
import DataTable from '../components/common/DataTable'
import Badge from '../components/common/Badge'
import Modal from '../components/common/Modal'
import ConfirmDialog from '../components/common/ConfirmDialog'
import { SearchBox, SelectFilter } from '../components/common/FilterBar'
import AssignmentForm from '../components/forms/AssignmentForm'
import { ASSIGNMENT_STATUSES } from '../data/constants'
import { byId, fmtDateTime, isRequestable } from '../utils/calculations'
import { exportCsv } from '../utils/csvExport'

const NEXT_LABEL = { Assigned: 'Mark picked up', 'Picked Up': 'Mark in transit', 'In Transit': 'Mark delivered' }

function Progress({ status }) {
  const idx = ASSIGNMENT_STATUSES.indexOf(status)
  return (
    <div className="progress" role="img" aria-label={`Progress: ${status}`}>
      <div className="progress-bar"><span style={{ width: `${((idx + 1) / ASSIGNMENT_STATUSES.length) * 100}%` }} /></div>
      <span className="muted small">{idx + 1} of {ASSIGNMENT_STATUSES.length}</span>
    </div>
  )
}

export default function Assignments() {
  const { db, user, can, createAssignment, setAssignmentStatus, cancelAssignment } = useApp()
  const [params, setParams] = useSearchParams()
  const [q, setQ] = useState('')
  const [status, setStatus] = useState('')
  const [modal, setModal] = useState(null) // { initial }
  const [confirm, setConfirm] = useState(null)

  // Requests / AI pages link here with ?request=R-1005&package=P-002&servings=40
  useEffect(() => {
    if (params.get('request') && can('assign')) {
      setModal({ initial: { requestId: params.get('request'), packageId: params.get('package') || '', servings: params.get('servings') || '' } })
      setParams({}, { replace: true })
    }
  }, [params, can, setParams])

  const donors = useMemo(() => byId(db.donors), [db.donors])
  const ngos = useMemo(() => byId(db.ngos), [db.ngos])
  const pkgs = useMemo(() => byId(db.packages), [db.packages])
  const vols = useMemo(() => byId(db.volunteers), [db.volunteers])

  // Only these requests can receive food: waiting, from a verified NGO, with no active assignment.
  const eligibleRequests = db.requests.filter((r) => ['Pending', 'Approved'].includes(r.status) && ngos[r.ngoId]?.verification === 'Verified' && !db.assignments.some((a) => a.requestId === r.id && a.status !== 'Delivered'))
  const availablePackages = db.packages.filter(isRequestable)

  const mine = user.role === 'Volunteer' ? db.assignments.filter((a) => a.volunteerId === user.linkedId) : db.assignments
  const rows = mine.filter((a) => {
    const t = q.trim().toLowerCase()
    return (!t || `${a.id} ${a.packageId} ${a.requestId} ${donors[a.donorId]?.organization} ${ngos[a.ngoId]?.name}`.toLowerCase().includes(t)) && (!status || a.status === status)
  })

  const submit = async (values) => {
    if (await createAssignment(values)) setModal(null)
  }

  const columns = [
    { key: 'id', header: 'Assignment', render: (a) => <><strong>{a.id}</strong><div className="muted small">{a.packageId} - {a.requestId}</div></> },
    { key: 'donor', header: 'Donor', sortValue: (a) => donors[a.donorId]?.organization, render: (a) => <><div>{donors[a.donorId]?.organization}</div><div className="muted small">{pkgs[a.packageId]?.name}</div></> },
    { key: 'ngo', header: 'NGO', sortValue: (a) => ngos[a.ngoId]?.name, render: (a) => ngos[a.ngoId]?.name },
    { key: 'servings', header: 'Servings', sortValue: (a) => a.servings },
    { key: 'route', header: 'Pickup to destination', sortable: false, render: (a) => <div className="route"><span>{a.pickupLocation}</span><ArrowRight size={12} /><span>{a.destination}</span></div> },
    { key: 'pickupAt', header: 'Pickup', sortValue: (a) => new Date(a.pickupAt).getTime(), render: (a) => fmtDateTime(a.pickupAt) },
    { key: 'volunteer', header: 'Volunteer', sortValue: (a) => vols[a.volunteerId]?.name, render: (a) => <>{vols[a.volunteerId]?.name}<div className="muted small">{vols[a.volunteerId]?.vehicle}</div></> },
    { key: 'status', header: 'Status', render: (a) => <><Badge>{a.status}</Badge><Progress status={a.status} /></> },
    { key: 'actions', header: '', sortable: false, className: 'actions', render: (a) => (
      <div className="row-actions">
        {can('updateDelivery') && NEXT_LABEL[a.status] && (
          <button className="btn btn-primary btn-sm" onClick={() => setAssignmentStatus(a.id, ASSIGNMENT_STATUSES[ASSIGNMENT_STATUSES.indexOf(a.status) + 1])}>{NEXT_LABEL[a.status]}</button>
        )}
        {can('assign') && a.status === 'Assigned' && <button className="icon-btn danger" aria-label={`Cancel ${a.id}`} title="Cancel assignment" onClick={() => setConfirm(a)}><Undo2 size={16} /></button>}
      </div>
    ) },
  ]

  const active = mine.filter((a) => a.status !== 'Delivered').length
  return (
    <>
      <PageHeader title="Assignments and distribution" subtitle={`${active} active ${active === 1 ? 'assignment' : 'assignments'}. Completed deliveries move to Distribution History.`}
        actions={<>
          <button className="btn btn-secondary" onClick={() => exportCsv('foodbridge-assignments.csv', [
            { header: 'Assignment', value: (a) => a.id }, { header: 'Package', value: (a) => a.packageId }, { header: 'Request', value: (a) => a.requestId },
            { header: 'Donor', value: (a) => donors[a.donorId]?.organization }, { header: 'NGO', value: (a) => ngos[a.ngoId]?.name }, { header: 'Servings', value: (a) => a.servings },
            { header: 'Pickup location', value: (a) => a.pickupLocation }, { header: 'Destination', value: (a) => a.destination }, { header: 'Pickup time', value: (a) => a.pickupAt },
            { header: 'Volunteer', value: (a) => vols[a.volunteerId]?.name }, { header: 'Status', value: (a) => a.status },
          ], rows)}><Download size={16} /> Export CSV</button>
          {can('assign') && <button className="btn btn-primary" onClick={() => setModal({ initial: {} })}><Plus size={16} /> New assignment</button>}
        </>} />
      <div className="card">
        <div className="toolbar">
          <SearchBox value={q} onChange={setQ} placeholder="Search by ID, donor or NGO" label="Search assignments" />
          <SelectFilter label="Statuses" value={status} onChange={setStatus} options={ASSIGNMENT_STATUSES} />
        </div>
        <DataTable columns={columns} rows={rows} pageSize={db.settings.pageSize} caption="Assignments" defaultSort={{ key: 'pickupAt', dir: 'desc' }} emptyTitle="No assignments found" emptyMessage={user.role === 'Volunteer' ? 'Assignments given to you will appear here.' : 'Assign an available package to a waiting request.'} />
      </div>

      {modal && (
        <Modal title="Assign food to a request" size="lg" onClose={() => setModal(null)}>
          {eligibleRequests.length === 0 || availablePackages.length === 0 ? (
            <p className="muted">{eligibleRequests.length === 0 ? 'No eligible requests. A request must be pending or approved, from a verified NGO, with no active assignment.' : 'No available packages. Food must be unexpired with servings left.'}</p>
          ) : null}
          <AssignmentForm requests={eligibleRequests} packages={availablePackages} volunteers={db.volunteers} ngos={db.ngos} initial={modal.initial} onSubmit={submit} onCancel={() => setModal(null)} />
        </Modal>
      )}
      {confirm && (
        <ConfirmDialog title={`Cancel ${confirm.id}?`} message="The servings go back into the package and the request returns to Approved so it can be assigned again."
          confirmLabel="Cancel assignment" onConfirm={async () => { await cancelAssignment(confirm.id); setConfirm(null) }} onCancel={() => setConfirm(null)} />
      )}
    </>
  )
}
