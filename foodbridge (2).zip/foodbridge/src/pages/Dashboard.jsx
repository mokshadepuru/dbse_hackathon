import { useMemo, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { AlertTriangle, ClipboardList, Leaf, Package, PackagePlus, Plus, Salad, Timer, Truck, Utensils } from 'lucide-react'
import { useApp } from '../context/AppContext'
import PageHeader from '../components/common/PageHeader'
import StatCard from '../components/common/StatCard'
import Badge from '../components/common/Badge'
import ChartCard, { RangeToggle } from '../components/charts/ChartCard'
import { ActivityAreaChart, DonutChart } from '../components/charts/Charts'
import { byId, dailySeries, fmtDateTime, fmtNumber, foodFlow, hoursUntil, packageStatus, timeLeft } from '../utils/calculations'
import { EmptyState } from '../components/common/States'

export default function Dashboard() {
  const { db, metrics, can, user } = useApp()
  const nav = useNavigate()
  const [range, setRange] = useState(14)
  const ngos = useMemo(() => byId(db.ngos), [db.ngos])
  const donors = useMemo(() => byId(db.donors), [db.donors])

  const recentDonations = [...db.packages].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).slice(0, 5)
  const recentRequests = [...db.requests].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).slice(0, 5)
  const urgent = db.requests
    .filter((r) => ['Pending', 'Approved'].includes(r.status) && ['High', 'Critical'].includes(r.urgency))
    .sort((a, b) => new Date(a.neededBy) - new Date(b.neededBy))
  const activity = useMemo(() => dailySeries(db, range), [db, range])
  const flow = useMemo(() => foodFlow(db), [db])

  return (
    <>
      <PageHeader
        title={`Welcome back, ${user.name.split(' ')[0]}`}
        subtitle="Here is what is happening across donations, requests and deliveries today."
        actions={<>
          {can('addPackage') && <button className="btn btn-primary" onClick={() => nav('/packages?new=1')}><PackagePlus size={16} /> Add donation</button>}
          {can('createRequest') && <button className="btn btn-secondary" onClick={() => nav('/requests?new=1')}><Plus size={16} /> Create request</button>}
        </>}
      />

      <div className="grid grid-3">
        <StatCard icon={Package} label="Total food donations" value={fmtNumber(metrics.totalDonations)} hint={`${metrics.activeDonors} active donors`} />
        <StatCard icon={Salad} label="Available food packages" value={metrics.availablePackages} hint={`${metrics.expiringSoon} expiring soon`} tone="amber" />
        <StatCard icon={ClipboardList} label="Active NGO requests" value={metrics.activeRequests} hint={`${metrics.verifiedNgos} verified NGOs`} tone="blue" />
        <StatCard icon={Truck} label="Pending assignments" value={metrics.pendingAssignments} hint="Requests waiting for food" tone="amber" />
        <StatCard icon={Utensils} label="Meals distributed" value={fmtNumber(metrics.mealsDistributed)} hint={`${metrics.completionRate}% request completion`} />
        <StatCard icon={Leaf} label="Food waste prevented" value={`${fmtNumber(metrics.wastePreventedKg)} kg`} hint="Estimated at 0.4 kg per meal" />
      </div>

      <div className="grid grid-2-1 mt">
        <ChartCard title="Donation activity" subtitle="Food packages listed per day"
          controls={<RangeToggle value={range} onChange={setRange} options={[{ value: 7, label: '7 days' }, { value: 14, label: '14 days' }, { value: 30, label: '30 days' }]} />}>
          <ActivityAreaChart data={activity} />
        </ChartCard>
        <ChartCard title="Food distribution" subtitle="Where listed servings are right now">
          {flow.length ? <DonutChart data={flow} /> : <EmptyState title="No food listed yet" />}
        </ChartCard>
      </div>

      <div className="grid grid-2-1 mt">
        <section className="card">
          <div className="card-head"><h3>Recent donations</h3><Link className="link-btn" to="/packages">View all</Link></div>
          <div className="table-wrap">
            <table className="table table-compact">
              <thead><tr><th>Package</th><th>Donor</th><th>Servings</th><th>Expires</th><th>Status</th></tr></thead>
              <tbody>
                {recentDonations.map((p) => {
                  const status = packageStatus(p)
                  return (
                    <tr key={p.id}>
                      <td data-label="Package"><strong>{p.name}</strong><div className="muted small">{p.id}</div></td>
                      <td data-label="Donor">{donors[p.donorId]?.organization}</td>
                      <td data-label="Servings">{p.availableServings}/{p.servings}</td>
                      <td data-label="Expires">{timeLeft(p.expiresAt)}</td>
                      <td data-label="Status"><Badge tone={status === 'Available' && hoursUntil(p.expiresAt) <= db.settings.expiryWindowHours ? 'amber' : undefined}>{status === 'Available' && hoursUntil(p.expiresAt) <= db.settings.expiryWindowHours ? 'Expiring soon' : status}</Badge></td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </section>

        <section className="card urgent-card">
          <div className="card-head"><h3><AlertTriangle size={17} aria-hidden="true" /> Urgent requests</h3><Link className="link-btn" to="/requests">View all</Link></div>
          {urgent.length === 0 ? <EmptyState title="No urgent requests" message="High and critical requests waiting for food will show here." /> : (
            <ul className="urgent-list">
              {urgent.slice(0, 5).map((r) => (
                <li key={r.id}>
                  <div>
                    <strong>{ngos[r.ngoId]?.name}</strong>
                    <span className="muted small">{r.quantity} {r.category} - {r.location}</span>
                    <span className="small urgent-time"><Timer size={12} /> needed {timeLeft(r.neededBy)}</span>
                  </div>
                  <Badge>{r.urgency}</Badge>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>

      <section className="card mt">
        <div className="card-head"><h3>Recent NGO requests</h3><Link className="link-btn" to="/requests">View all</Link></div>
        <div className="table-wrap">
          <table className="table table-compact">
            <thead><tr><th>ID</th><th>NGO</th><th>Category</th><th>Servings</th><th>Needed by</th><th>Urgency</th><th>Status</th></tr></thead>
            <tbody>
              {recentRequests.map((r) => (
                <tr key={r.id}>
                  <td data-label="ID">{r.id}</td>
                  <td data-label="NGO">{ngos[r.ngoId]?.name}</td>
                  <td data-label="Category">{r.category}</td>
                  <td data-label="Servings">{r.quantity}</td>
                  <td data-label="Needed by">{fmtDateTime(r.neededBy)}</td>
                  <td data-label="Urgency"><Badge>{r.urgency}</Badge></td>
                  <td data-label="Status"><Badge>{r.status}</Badge></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </>
  )
}
