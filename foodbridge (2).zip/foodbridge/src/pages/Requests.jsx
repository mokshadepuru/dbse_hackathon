import { useEffect, useMemo, useState } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { AlertTriangle, Check, Download, Eye, PackageSearch, Plus, X } from 'lucide-react'
import { useApp } from '../context/AppContext'
import PageHeader from '../components/common/PageHeader'
import DataTable from '../components/common/DataTable'
import Badge from '../components/common/Badge'
import Modal from '../components/common/Modal'
import { SearchBox, SelectFilter } from '../components/common/FilterBar'
import RequestForm from '../components/forms/RequestForm'
import { CATEGORIES, REQUEST_STATUSES, URGENCY } from '../data/constants'
import { byId, fmtDateTime, timeLeft } from '../utils/calculations'
import { exportCsv } from '../utils/csvExport'

const FLOW = ['Pending', 'Approved', 'Assigned', 'In Transit', 'Delivered']
const URGENCY_RANK = { Low: 0, Medium: 1, High: 2, Critical: 3 }

function Workflow({ status }) {
  if (status === 'Rejected') return <p className="flow-rejected"><X size={14} /> This request was rejected.</p>
  const idx = FLOW.indexOf(status)
  return (
    <ol className="flow" aria-label="Request workflow">
      {FLOW.map((s, i) => (
        <li key={s} className={i < idx ? 'done' : i === idx ? 'current' : ''} aria-current={i === idx ? 'step' : undefined}>
          <span className="flow-dot">{i < idx ? <Check size={12} /> : i + 1}</span>{s}
        </li>
      ))}
    </ol>
  )
}

export default function Requests() {
  const { db, user, can, addRequest, setRequestStatus } = useApp()
  const nav = useNavigate()
  const [params, setParams] = useSearchParams()
  const [q, setQ] = useState(params.get('q') || '')
  const [status, setStatus] = useState('')
  const [urgency, setUrgency] = useState('')
  const [category, setCategory] = useState('')
  const [modal, setModal] = useState(null) // { mode: 'new' | 'view', request }

  useEffect(() => {
    if (params.get('new') && can('createRequest')) {
      setModal({ mode: 'new' })
      setParams({}, { replace: true })
    }
  }, [params, can, setParams])

  const ngos = useMemo(() => byId(db.ngos), [db.ngos])
  const myNgo = user.role === 'NGO' ? user.linkedId : null
  const rows = db.requests
    .filter((r) => !myNgo || r.ngoId === myNgo) // NGO users only see their own requests
    .map((r) => ({ ...r, ngoName: ngos[r.ngoId]?.name || '' }))
    .filter((r) => {
      const t = q.trim().toLowerCase()
      return (!t || `${r.id} ${r.ngoName} ${r.category} ${r.location} ${r.reason}`.toLowerCase().includes(t))
        && (!status || r.status === status) && (!urgency || r.urgency === urgency) && (!category || r.category === category)
    })

  const create = async (values) => {
    if (await addRequest(values)) setModal(null)
  }
  const goAssign = (r) => nav(`/assignments?request=${r.id}`)
  const needsFood = (r) => ['Pending', 'Approved'].includes(r.status)

  const rowActions = (r) => (
    <div className="row-actions">
      <button className="icon-btn" aria-label={`View ${r.id}`} onClick={() => setModal({ mode: 'view', request: r })}><Eye size={16} /></button>
      {can('reviewRequest') && r.status === 'Pending' && (
        <>
          <button className="icon-btn ok" aria-label={`Approve ${r.id}`} title="Approve" onClick={() => setRequestStatus(r.id, 'Approved')}><Check size={16} /></button>
          <button className="icon-btn danger" aria-label={`Reject ${r.id}`} title="Reject" onClick={() => setRequestStatus(r.id, 'Rejected')}><X size={16} /></button>
        </>
      )}
      {can('assign') && needsFood(r) && <button className="btn btn-primary btn-sm" onClick={() => goAssign(r)}><PackageSearch size={14} /> Assign</button>}
    </div>
  )

  const columns = [
    { key: 'id', header: 'Request', render: (r) => <><strong>{r.id}</strong>{needsFood(r) && ['High', 'Critical'].includes(r.urgency) && <AlertTriangle size={14} className="urgent-flag" aria-label="Urgent" />}</> },
    { key: 'ngoName', header: 'NGO', render: (r) => <><div>{r.ngoName}</div><div className="muted small">{r.location}</div></> },
    { key: 'category', header: 'Category' },
    { key: 'quantity', header: 'Servings', sortValue: (r) => r.quantity, render: (r) => <>{r.quantity}<div className="muted small">{r.beneficiaries} people</div></> },
    { key: 'neededBy', header: 'Needed by', sortValue: (r) => new Date(r.neededBy).getTime(), render: (r) => <>{fmtDateTime(r.neededBy)}<div className="muted small">{timeLeft(r.neededBy)}</div></> },
    { key: 'urgency', header: 'Urgency', sortValue: (r) => URGENCY_RANK[r.urgency], render: (r) => <Badge>{r.urgency}</Badge> },
    { key: 'status', header: 'Status', render: (r) => <Badge>{r.status}</Badge> },
    { key: 'actions', header: '', sortable: false, className: 'actions', render: rowActions },
  ]

  const urgentOpen = rows.filter((r) => needsFood(r) && ['High', 'Critical'].includes(r.urgency)).length

  return (
    <>
      <PageHeader title="NGO requests" subtitle="Workflow: Pending, Approved, Assigned, In Transit, Delivered."
        actions={<>
          <button className="btn btn-secondary" onClick={() => exportCsv('foodbridge-requests.csv', [
            { header: 'Request ID', value: (r) => r.id }, { header: 'NGO', value: (r) => r.ngoName }, { header: 'Category', value: (r) => r.category },
            { header: 'Servings', value: (r) => r.quantity }, { header: 'Beneficiaries', value: (r) => r.beneficiaries }, { header: 'Needed by', value: (r) => r.neededBy },
            { header: 'Location', value: (r) => r.location }, { header: 'Urgency', value: (r) => r.urgency }, { header: 'Status', value: (r) => r.status }, { header: 'Reason', value: (r) => r.reason },
          ], rows)}><Download size={16} /> Export CSV</button>
          {can('createRequest') && <button className="btn btn-primary" onClick={() => setModal({ mode: 'new' })}><Plus size={16} /> New request</button>}
        </>} />

      {urgentOpen > 0 && (
        <div className="banner banner-urgent" role="status"><AlertTriangle size={18} /> {urgentOpen} high or critical request{urgentOpen > 1 ? 's are' : ' is'} waiting for food.
          <button className="link-btn" onClick={() => { setStatus(''); setUrgency('Critical') }}>Show critical</button>
        </div>
      )}

      <div className="card">
        <div className="toolbar">
          <SearchBox value={q} onChange={setQ} placeholder="Search requests, NGOs or reasons" label="Search requests" />
          <SelectFilter label="Statuses" value={status} onChange={setStatus} options={REQUEST_STATUSES} />
          <SelectFilter label="Urgency" value={urgency} onChange={setUrgency} options={URGENCY} allLabel="Any urgency" />
          <SelectFilter label="Categories" value={category} onChange={setCategory} options={CATEGORIES} />
        </div>
        <DataTable columns={columns} rows={rows} pageSize={db.settings.pageSize} caption="NGO requests"
          defaultSort={{ key: 'urgency', dir: 'desc' }} emptyTitle="No requests match" emptyMessage="Clear filters or create a new request." />
      </div>

      {modal?.mode === 'new' && (
        <Modal title="Create a food request" size="lg" onClose={() => setModal(null)}>
          <RequestForm ngos={myNgo ? db.ngos.filter((n) => n.id === myNgo) : db.ngos} fixedNgoId={myNgo || undefined} onSubmit={create} onCancel={() => setModal(null)} />
        </Modal>
      )}
      {modal?.mode === 'view' && (() => {
        // read the latest copy so the dialog reflects status changes
        const r = db.requests.find((x) => x.id === modal.request.id)
        const assignment = db.assignments.find((a) => a.requestId === r.id)
        return (
          <Modal title={`Request ${r.id}`} onClose={() => setModal(null)}
            footer={<>
              {can('reviewRequest') && r.status === 'Pending' && (<>
                <button className="btn btn-danger" onClick={() => setRequestStatus(r.id, 'Rejected')}>Reject</button>
                <button className="btn btn-primary" onClick={() => setRequestStatus(r.id, 'Approved')}>Approve</button>
              </>)}
              {can('reviewRequest') && r.status === 'Rejected' && <button className="btn btn-secondary" onClick={() => setRequestStatus(r.id, 'Pending')}>Reopen</button>}
              {can('assign') && needsFood(r) && <button className="btn btn-primary" onClick={() => goAssign(r)}>Assign food</button>}
              <button className="btn btn-secondary" onClick={() => setModal(null)}>Close</button>
            </>}>
            <Workflow status={r.status} />
            <dl className="detail-grid">
              <div><dt>NGO</dt><dd>{ngos[r.ngoId]?.name}</dd></div>
              <div><dt>Category</dt><dd>{r.category}</dd></div>
              <div><dt>Quantity</dt><dd>{r.quantity} servings</dd></div>
              <div><dt>Beneficiaries</dt><dd>{r.beneficiaries} people</dd></div>
              <div><dt>Needed by</dt><dd>{fmtDateTime(r.neededBy)} ({timeLeft(r.neededBy)})</dd></div>
              <div><dt>Location</dt><dd>{r.location}</dd></div>
              <div><dt>Urgency</dt><dd><Badge>{r.urgency}</Badge></dd></div>
              <div><dt>Status</dt><dd><Badge>{r.status}</Badge></dd></div>
            </dl>
            <h4>Reason</h4>
            <p>{r.reason}</p>
            {assignment && <p className="info-line">Linked assignment: <strong>{assignment.id}</strong> ({assignment.status}), {assignment.servings} servings from {assignment.packageId}.</p>}
          </Modal>
        )
      })()}
    </>
  )
}
