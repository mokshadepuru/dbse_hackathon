import { useMemo, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { CheckCircle2, Download, Leaf, Utensils } from 'lucide-react'
import { useApp } from '../context/AppContext'
import PageHeader from '../components/common/PageHeader'
import StatCard from '../components/common/StatCard'
import DataTable from '../components/common/DataTable'
import Badge from '../components/common/Badge'
import { SearchBox, SelectFilter } from '../components/common/FilterBar'
import { byId, fmtDateTime, fmtNumber, servingsToKg } from '../utils/calculations'
import { exportCsv } from '../utils/csvExport'

export default function DistributionHistory() {
  const { db } = useApp()
  const [params] = useSearchParams()
  const [q, setQ] = useState(params.get('q') || '')
  const [ngo, setNgo] = useState('')
  const [donor, setDonor] = useState('')
  const [from, setFrom] = useState('')
  const [to, setTo] = useState('')

  const donors = useMemo(() => byId(db.donors), [db.donors])
  const ngos = useMemo(() => byId(db.ngos), [db.ngos])
  const pkgs = useMemo(() => byId(db.packages), [db.packages])

  // Join distribution records with package / donor / NGO names (like SQL JOINs)
  const rows = useMemo(() => db.distributions.map((d) => ({
    ...d, packageName: pkgs[d.packageId]?.name || d.packageId, donorName: donors[d.donorId]?.organization || '', ngoName: ngos[d.ngoId]?.name || '',
  })), [db.distributions, pkgs, donors, ngos])

  const filtered = rows.filter((r) => {
    const t = q.trim().toLowerCase()
    const day = r.deliveredAt.slice(0, 10)
    return (!t || `${r.id} ${r.assignmentId} ${r.packageName} ${r.donorName} ${r.ngoName}`.toLowerCase().includes(t))
      && (!ngo || r.ngoId === ngo) && (!donor || r.donorId === donor) && (!from || day >= from) && (!to || day <= to)
  })

  const totalServings = filtered.reduce((s, r) => s + r.servings, 0)
  const meals = filtered.reduce((s, r) => s + r.mealsServed, 0)

  const columns = [
    { key: 'id', header: 'Record', render: (r) => <><strong>{r.id}</strong><div className="muted small">{r.assignmentId}</div></> },
    { key: 'packageName', header: 'Food package' },
    { key: 'donorName', header: 'Donor' },
    { key: 'ngoName', header: 'Received by' },
    { key: 'servings', header: 'Delivered', sortValue: (r) => r.servings, render: (r) => `${r.servings} servings` },
    { key: 'mealsServed', header: 'Meals served', sortValue: (r) => r.mealsServed },
    { key: 'deliveredAt', header: 'Delivered on', sortValue: (r) => new Date(r.deliveredAt).getTime(), render: (r) => fmtDateTime(r.deliveredAt) },
    { key: 'status', header: 'Status', render: (r) => <Badge>{r.status}</Badge> },
  ]

  return (
    <>
      <PageHeader title="Distribution history" subtitle="Every completed delivery, from donor to receiving NGO."
        actions={<button className="btn btn-secondary" onClick={() => exportCsv('foodbridge-distribution-history.csv', [
          { header: 'Record', value: (r) => r.id }, { header: 'Assignment', value: (r) => r.assignmentId }, { header: 'Food package', value: (r) => r.packageName },
          { header: 'Donor', value: (r) => r.donorName }, { header: 'Receiving NGO', value: (r) => r.ngoName }, { header: 'Servings delivered', value: (r) => r.servings },
          { header: 'Meals served', value: (r) => r.mealsServed }, { header: 'Delivered at', value: (r) => r.deliveredAt }, { header: 'Status', value: (r) => r.status },
        ], filtered)}><Download size={16} /> Export CSV</button>} />
      <div className="grid grid-3">
        <StatCard icon={CheckCircle2} label="Completed deliveries" value={filtered.length} hint="Matching current filters" />
        <StatCard icon={Utensils} label="Meals served" value={fmtNumber(meals)} hint={`${fmtNumber(totalServings)} servings delivered`} />
        <StatCard icon={Leaf} label="Waste prevented" value={`${fmtNumber(servingsToKg(totalServings))} kg`} hint="Estimated at 0.4 kg per meal" />
      </div>
      <div className="card mt">
        <div className="toolbar">
          <SearchBox value={q} onChange={setQ} placeholder="Search records, packages, donors or NGOs" label="Search history" />
          <SelectFilter label="NGOs" value={ngo} onChange={setNgo} options={db.ngos.map((n) => ({ value: n.id, label: n.name }))} />
          <SelectFilter label="Donors" value={donor} onChange={setDonor} options={db.donors.map((d) => ({ value: d.id, label: d.organization }))} />
          <label className="date-filter">From <input type="date" value={from} onChange={(e) => setFrom(e.target.value)} aria-label="From date" /></label>
          <label className="date-filter">To <input type="date" value={to} onChange={(e) => setTo(e.target.value)} aria-label="To date" /></label>
        </div>
        <DataTable columns={columns} rows={filtered} pageSize={db.settings.pageSize} caption="Distribution history" defaultSort={{ key: 'deliveredAt', dir: 'desc' }}
          emptyTitle="No completed deliveries match" emptyMessage="Deliveries appear here once an assignment is marked Delivered." />
      </div>
    </>
  )
}
