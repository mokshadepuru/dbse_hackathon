import { useMemo, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { BadgeCheck, Download, Eye, Mail, MapPin, Pencil, Phone, Plus, Users } from 'lucide-react'
import { useApp } from '../context/AppContext'
import PageHeader from '../components/common/PageHeader'
import DataTable from '../components/common/DataTable'
import Badge from '../components/common/Badge'
import Modal from '../components/common/Modal'
import { SearchBox, SelectFilter } from '../components/common/FilterBar'
import NgoForm from '../components/forms/NgoForm'
import { LOCATIONS, VERIFICATION } from '../data/constants'
import { fmtNumber } from '../utils/calculations'
import { exportCsv } from '../utils/csvExport'

export default function NGOs() {
  const { db, can, addNgo, updateNgo } = useApp()
  const [params] = useSearchParams()
  const [q, setQ] = useState(params.get('q') || '')
  const [area, setArea] = useState('')
  const [verification, setVerification] = useState('')
  const [modal, setModal] = useState(null)

  const rows = useMemo(() => db.ngos.map((n) => ({
    ...n,
    openRequests: db.requests.filter((r) => r.ngoId === n.id && ['Pending', 'Approved', 'Assigned', 'In Transit'].includes(r.status)).length,
    received: db.distributions.filter((d) => d.ngoId === n.id).reduce((s, d) => s + d.servings, 0),
  })), [db])

  const filtered = rows.filter((n) => {
    const t = q.trim().toLowerCase()
    return (!t || `${n.id} ${n.name} ${n.contactPerson} ${n.email} ${n.serviceArea}`.toLowerCase().includes(t))
      && (!area || n.serviceArea === area) && (!verification || n.verification === verification)
  })

  const save = async (values) => {
    const ok = modal.mode === 'edit' ? await updateNgo(modal.ngo.id, values) : await addNgo(values)
    if (ok) setModal(null)
  }

  const columns = [
    { key: 'name', header: 'NGO', render: (n) => <><strong>{n.name}</strong><div className="muted small">{n.id} - {n.contactPerson}</div></> },
    { key: 'verification', header: 'Verification', render: (n) => <span className="verif">{n.verification === 'Verified' && <BadgeCheck size={15} className="verif-icon" />}<Badge>{n.verification}</Badge></span> },
    { key: 'phone', header: 'Contact', sortable: false, render: (n) => <><div>{n.phone}</div><div className="muted small">{n.email}</div></> },
    { key: 'serviceArea', header: 'Service area' },
    { key: 'beneficiaries', header: 'Beneficiaries', sortValue: (n) => n.beneficiaries, render: (n) => fmtNumber(n.beneficiaries) },
    { key: 'capacity', header: 'Capacity / day', sortValue: (n) => n.capacity, render: (n) => `${fmtNumber(n.capacity)} meals` },
    { key: 'needs', header: 'Food needs', sortable: false, render: (n) => <div className="tag-row">{n.requirements.length ? n.requirements.map((r) => <span key={r} className="tag">{r}</span>) : <span className="muted small">Not set</span>}</div> },
    { key: 'actions', header: '', sortable: false, className: 'actions', render: (n) => (
      <div className="row-actions">
        <button className="icon-btn" aria-label={`View ${n.name}`} onClick={() => setModal({ mode: 'view', ngo: n })}><Eye size={16} /></button>
        {can('manageNgos') && <button className="icon-btn" aria-label={`Edit ${n.name}`} onClick={() => setModal({ mode: 'edit', ngo: n })}><Pencil size={16} /></button>}
      </div>
    ) },
  ]

  return (
    <>
      <PageHeader title="NGOs" subtitle="Only verified NGOs can receive food assignments."
        actions={<>
          <button className="btn btn-secondary" onClick={() => exportCsv('foodbridge-ngos.csv', [
            { header: 'ID', value: (r) => r.id }, { header: 'Name', value: (r) => r.name }, { header: 'Verification', value: (r) => r.verification },
            { header: 'Contact person', value: (r) => r.contactPerson }, { header: 'Phone', value: (r) => r.phone }, { header: 'Email', value: (r) => r.email },
            { header: 'Service area', value: (r) => r.serviceArea }, { header: 'Beneficiaries', value: (r) => r.beneficiaries }, { header: 'Capacity (meals/day)', value: (r) => r.capacity },
            { header: 'Food needs', value: (r) => r.requirements.join('; ') },
          ], filtered)}><Download size={16} /> Export CSV</button>
          {can('manageNgos') && <button className="btn btn-primary" onClick={() => setModal({ mode: 'add' })}><Plus size={16} /> Add NGO</button>}
        </>} />
      <div className="card">
        <div className="toolbar">
          <SearchBox value={q} onChange={setQ} placeholder="Search by NGO, contact or area" label="Search NGOs" />
          <SelectFilter label="Service areas" value={area} onChange={setArea} options={LOCATIONS} />
          <SelectFilter label="Verification" value={verification} onChange={setVerification} options={VERIFICATION} allLabel="Any verification" />
        </div>
        <DataTable columns={columns} rows={filtered} pageSize={db.settings.pageSize} caption="NGOs" emptyTitle="No NGOs match your filters" emptyMessage="Clear the search or filters to see all NGOs." />
      </div>

      {modal && modal.mode !== 'view' && (
        <Modal title={modal.mode === 'edit' ? 'Edit NGO profile' : 'Add NGO'} size="lg" onClose={() => setModal(null)}>
          <NgoForm ngo={modal.ngo} canVerify={can('manageNgos')} onSubmit={save} onCancel={() => setModal(null)} />
        </Modal>
      )}
      {modal?.mode === 'view' && (
        <Modal title={modal.ngo.name} onClose={() => setModal(null)} size="sm" footer={<button className="btn btn-secondary" onClick={() => setModal(null)}>Close</button>}>
          <div className="detail-list">
            <Badge>{modal.ngo.verification}</Badge>
            <p><strong>{modal.ngo.contactPerson}</strong></p>
            <p><Phone size={14} /> {modal.ngo.phone}</p>
            <p><Mail size={14} /> {modal.ngo.email}</p>
            <p><MapPin size={14} /> {modal.ngo.address ? `${modal.ngo.address}, ` : ''}{modal.ngo.serviceArea}</p>
            <p><Users size={14} /> {fmtNumber(modal.ngo.beneficiaries)} beneficiaries - {fmtNumber(modal.ngo.capacity)} meals/day capacity</p>
            <p className="muted">{modal.ngo.openRequests} open requests - {fmtNumber(modal.ngo.received)} servings received so far</p>
            <div className="tag-row">{modal.ngo.requirements.map((r) => <span key={r} className="tag">{r}</span>)}</div>
          </div>
        </Modal>
      )}
    </>
  )
}
