import { useMemo, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { Download, Pencil, Plus, Eye, Mail, MapPin, Phone } from 'lucide-react'
import { useApp } from '../context/AppContext'
import PageHeader from '../components/common/PageHeader'
import DataTable from '../components/common/DataTable'
import Badge from '../components/common/Badge'
import Modal from '../components/common/Modal'
import { SearchBox, SelectFilter } from '../components/common/FilterBar'
import DonorForm from '../components/forms/DonorForm'
import { DONOR_TYPES, LOCATIONS } from '../data/constants'
import { fmtDate } from '../utils/calculations'
import { exportCsv } from '../utils/csvExport'

export default function Donors() {
  const { db, can, addDonor, updateDonor } = useApp()
  const [params] = useSearchParams()
  const [q, setQ] = useState(params.get('q') || '')
  const [loc, setLoc] = useState('')
  const [status, setStatus] = useState('')
  const [type, setType] = useState('')
  const [modal, setModal] = useState(null) // { mode: 'add' | 'edit' | 'view', donor }

  // Derived columns: total donations come from the packages table (like a SQL COUNT ... GROUP BY donor_id)
  const rows = useMemo(() => db.donors.map((d) => {
    const pk = db.packages.filter((p) => p.donorId === d.id)
    return { ...d, totalDonations: pk.length, totalServings: pk.reduce((s, p) => s + p.servings, 0) }
  }), [db])

  const filtered = rows.filter((d) => {
    const t = q.trim().toLowerCase()
    return (!t || `${d.id} ${d.name} ${d.organization} ${d.email} ${d.location}`.toLowerCase().includes(t))
      && (!loc || d.location === loc) && (!status || d.status === status) && (!type || d.type === type)
  })

  const save = async (values) => {
    const ok = modal.mode === 'edit' ? await updateDonor(modal.donor.id, values) : await addDonor(values)
    if (ok) setModal(null)
  }

  const columns = [
    { key: 'organization', header: 'Donor', render: (d) => <><strong>{d.organization}</strong><div className="muted small">{d.name} - {d.id}</div></> },
    { key: 'type', header: 'Type' },
    { key: 'phone', header: 'Contact', sortable: false, render: (d) => <><div>{d.phone}</div><div className="muted small">{d.email}</div></> },
    { key: 'location', header: 'Location' },
    { key: 'totalDonations', header: 'Donations', sortValue: (d) => d.totalDonations, render: (d) => <>{d.totalDonations} <span className="muted small">({d.totalServings} servings)</span></> },
    { key: 'registeredOn', header: 'Registered', render: (d) => fmtDate(d.registeredOn) },
    { key: 'status', header: 'Status', render: (d) => <Badge>{d.status}</Badge> },
    { key: 'actions', header: '', sortable: false, className: 'actions', render: (d) => (
      <div className="row-actions">
        <button className="icon-btn" aria-label={`View ${d.organization}`} onClick={() => setModal({ mode: 'view', donor: d })}><Eye size={16} /></button>
        {can('manageDonors') && <button className="icon-btn" aria-label={`Edit ${d.organization}`} onClick={() => setModal({ mode: 'edit', donor: d })}><Pencil size={16} /></button>}
      </div>
    ) },
  ]

  return (
    <>
      <PageHeader title="Donors" subtitle={`${rows.filter((d) => d.status === 'Active').length} active of ${rows.length} registered donors`}
        actions={<>
          <button className="btn btn-secondary" onClick={() => exportCsv('foodbridge-donors.csv', [
            { header: 'ID', value: (r) => r.id }, { header: 'Contact person', value: (r) => r.name }, { header: 'Organisation', value: (r) => r.organization },
            { header: 'Type', value: (r) => r.type }, { header: 'Phone', value: (r) => r.phone }, { header: 'Email', value: (r) => r.email },
            { header: 'Location', value: (r) => r.location }, { header: 'Total donations', value: (r) => r.totalDonations }, { header: 'Registered', value: (r) => r.registeredOn }, { header: 'Status', value: (r) => r.status },
          ], filtered)}><Download size={16} /> Export CSV</button>
          {can('manageDonors') && <button className="btn btn-primary" onClick={() => setModal({ mode: 'add' })}><Plus size={16} /> Add donor</button>}
        </>} />
      <div className="card">
        <div className="toolbar">
          <SearchBox value={q} onChange={setQ} placeholder="Search by name, organisation or email" label="Search donors" />
          <SelectFilter label="Locations" value={loc} onChange={setLoc} options={LOCATIONS} />
          <SelectFilter label="Types" value={type} onChange={setType} options={DONOR_TYPES} />
          <SelectFilter label="Statuses" value={status} onChange={setStatus} options={['Active', 'Inactive']} />
        </div>
        <DataTable columns={columns} rows={filtered} pageSize={db.settings.pageSize} caption="Donors" emptyTitle="No donors match your filters" emptyMessage="Clear the search or filters to see all donors." />
      </div>

      {modal && modal.mode !== 'view' && (
        <Modal title={modal.mode === 'edit' ? 'Edit donor' : 'Add donor'} onClose={() => setModal(null)}>
          <DonorForm donor={modal.donor} onSubmit={save} onCancel={() => setModal(null)} />
        </Modal>
      )}
      {modal?.mode === 'view' && (
        <Modal title={modal.donor.organization} onClose={() => setModal(null)} size="sm"
          footer={<button className="btn btn-secondary" onClick={() => setModal(null)}>Close</button>}>
          <div className="detail-list">
            <Badge>{modal.donor.status}</Badge>
            <p><strong>{modal.donor.name}</strong> - {modal.donor.type}</p>
            <p><Phone size={14} /> {modal.donor.phone}</p>
            <p><Mail size={14} /> {modal.donor.email}</p>
            <p><MapPin size={14} /> {modal.donor.address ? `${modal.donor.address}, ` : ''}{modal.donor.location}</p>
            <p className="muted">Registered {fmtDate(modal.donor.registeredOn)} - {modal.donor.totalDonations} donations ({modal.donor.totalServings} servings)</p>
          </div>
        </Modal>
      )}
    </>
  )
}
