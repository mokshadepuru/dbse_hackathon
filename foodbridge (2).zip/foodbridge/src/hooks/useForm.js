import { useState } from 'react'

// Minimal form helper.
//   const f = useForm(initialValues, validate)   // validate(values) -> { field: 'message' }
//   <input value={f.values.name} onChange={f.bind('name')} />
//   f.handleSubmit(async (values) => {...})  -> runs validate first
export default function useForm(initial, validate) {
  const [values, setValues] = useState(initial)
  const [errors, setErrors] = useState({})
  const [saving, setSaving] = useState(false)

  const bind = (name) => (e) => {
    const value = e.target.type === 'number' && e.target.value !== '' ? e.target.value : e.target.value
    setValues((v) => ({ ...v, [name]: value }))
    if (errors[name]) setErrors((er) => ({ ...er, [name]: undefined }))
  }
  const set = (name, value) => setValues((v) => ({ ...v, [name]: value }))

  const handleSubmit = (onValid) => async (e) => {
    e.preventDefault()
    const found = validate ? validate(values) : {}
    const clean = Object.fromEntries(Object.entries(found).filter(([, m]) => m))
    setErrors(clean)
    if (Object.keys(clean).length) {
      // move focus to the first invalid field so keyboard users know what to fix
      setTimeout(() => document.querySelector('[aria-invalid="true"]')?.focus(), 0)
      return
    }
    setSaving(true)
    try {
      await onValid(values)
    } finally {
      setSaving(false)
    }
  }
  return { values, errors, bind, set, setValues, handleSubmit, saving }
}
