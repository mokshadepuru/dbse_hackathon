// Shared application state. Every page reads data from here, so a change on one page
// (for example a new assignment) shows up everywhere else after reload().
import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react'
import { donorService } from '../services/donorService'
import { ngoService } from '../services/ngoService'
import { donationService } from '../services/donationService'
import { requestService } from '../services/requestService'
import { assignmentService } from '../services/assignmentService'
import { settingsService } from '../services/settingsService'
import { authService } from '../services/authService'
import { computeMetrics } from '../utils/calculations'

const AppContext = createContext(null)
export const useApp = () => useContext(AppContext)

const USER_KEY = 'foodbridge.user'
const readUser = () => {
  try {
    return JSON.parse(localStorage.getItem(USER_KEY))
  } catch {
    return null
  }
}

// Which roles may do what. The UI hides controls; a real backend must also enforce this with JWT roles.
export const PERMISSIONS = {
  manageDonors: ['Admin'],
  manageNgos: ['Admin'],
  addPackage: ['Admin', 'Donor'],
  editPackage: ['Admin', 'Donor'],
  createRequest: ['Admin', 'NGO'],
  reviewRequest: ['Admin'],
  assign: ['Admin'],
  updateDelivery: ['Admin', 'Volunteer'],
  viewInsights: ['Admin', 'NGO'],
}

export function AppProvider({ children }) {
  const [db, setDb] = useState(null)
  const [loading, setLoading] = useState(true)
  const [loadError, setLoadError] = useState('')
  const [user, setUser] = useState(readUser)
  const [toasts, setToasts] = useState([])
  const [, setTick] = useState(0)

  const toast = useCallback((type, message) => {
    const id = Date.now() + Math.random()
    setToasts((t) => [...t, { id, type, message }])
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 4500)
  }, [])
  const dismissToast = (id) => setToasts((t) => t.filter((x) => x.id !== id))

  const reload = useCallback(async () => {
    try {
      const [donors, ngos, packages, requests, assignments, distributions, volunteers, notifications, settings, meta] = await Promise.all([
        donorService.list(), ngoService.list(), donationService.list(), requestService.list(),
        assignmentService.list(), assignmentService.distributions(), assignmentService.volunteers(),
        settingsService.notifications(), settingsService.get(), settingsService.meta(),
      ])
      setDb({ donors, ngos, packages, requests, assignments, distributions, volunteers, notifications, settings, ...meta })
      setLoadError('')
    } catch (e) {
      setLoadError(e.message || 'Could not load data.')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    if (user) reload()
    else setLoading(false)
  }, [user, reload])

  // Re-render every minute so "expires in 3 h" style labels stay fresh.
  useEffect(() => {
    const t = setInterval(() => setTick((n) => n + 1), 60000)
    return () => clearInterval(t)
  }, [])

  // run(): call a service, reload data, show a toast. Returns the result, or null on error.
  const run = useCallback(async (fn, successMessage) => {
    try {
      const result = await fn()
      await reload()
      if (successMessage) toast('success', successMessage)
      return result ?? true
    } catch (e) {
      toast('error', e.message || 'Something went wrong.')
      return null
    }
  }, [reload, toast])

  const actions = useMemo(() => ({
    addDonor: (d) => run(() => donorService.create(d), 'Donor added.'),
    updateDonor: (id, d) => run(() => donorService.update(id, d), 'Donor details saved.'),
    addNgo: (n) => run(() => ngoService.create(n), 'NGO profile added.'),
    updateNgo: (id, n) => run(() => ngoService.update(id, n), 'NGO profile saved.'),
    addPackage: (p) => run(() => donationService.create(p), 'Food package listed.'),
    updatePackage: (id, p) => run(() => donationService.update(id, p), 'Food package saved.'),
    deletePackage: (id) => run(() => donationService.remove(id), 'Food package deleted.'),
    addRequest: (r) => run(() => requestService.create(r), 'Request created.'),
    setRequestStatus: (id, s) => run(() => requestService.setStatus(id, s), `Request ${id} ${s.toLowerCase()}.`),
    createAssignment: (a) => run(() => assignmentService.create(a), 'Assignment created.'),
    setAssignmentStatus: (id, s) => run(() => assignmentService.setStatus(id, s), `${id} marked ${s}.`),
    cancelAssignment: (id) => run(() => assignmentService.cancel(id), `${id} cancelled.`),
    markRead: (id) => run(() => settingsService.markRead(id)),
    markAllRead: () => run(() => settingsService.markAllRead()),
    saveSettings: (s) => run(() => settingsService.save(s), 'Settings saved.'),
    resetDemo: () => run(() => settingsService.reset(), 'Demo data reset to the original sample.'),
  }), [run])

  const login = async (email, password) => {
    const u = await authService.login(email, password)
    localStorage.setItem(USER_KEY, JSON.stringify(u))
    setLoading(true)
    setUser(u)
  }
  const register = async (payload) => {
    const u = await authService.register(payload)
    localStorage.setItem(USER_KEY, JSON.stringify(u))
    setLoading(true)
    setUser(u)
  }
  // Profile edits are kept in this browser only (the mock backend has no profile endpoint).
  const updateProfile = (patch) => {
    const u = { ...user, ...patch }
    localStorage.setItem(USER_KEY, JSON.stringify(u))
    setUser(u)
    toast('success', 'Profile saved.')
  }
  const logout = () => {
    authService.logout()
    localStorage.removeItem(USER_KEY)
    setDb(null)
    setUser(null)
  }

  const metrics = useMemo(() => (db ? computeMetrics(db) : null), [db])
  const can = (perm) => !!user && PERMISSIONS[perm].includes(user.role)

  const value = { db, loading, loadError, reload, user, login, register, logout, updateProfile, toasts, toast, dismissToast, metrics, can, ...actions }
  return <AppContext.Provider value={value}>{children}</AppContext.Provider>
}
