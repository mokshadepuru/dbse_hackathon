// Assignment & distribution service
// -> GET/POST /assignments, PATCH /assignments/{id}/status, DELETE /assignments/{id},
//    GET /distributions, GET /volunteers
import { api } from './api'
export const assignmentService = {
  list: () => api.get('/assignments'),
  create: (a) => api.post('/assignments', a),
  setStatus: (id, status) => api.patch(`/assignments/${id}/status`, { status }),
  cancel: (id) => api.del(`/assignments/${id}`),
  distributions: () => api.get('/distributions'),
  volunteers: () => api.get('/volunteers'),
}
