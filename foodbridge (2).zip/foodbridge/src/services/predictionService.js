// Demand prediction & smart prioritisation service.
//
// IMPORTANT: the numbers below come from a transparent DEMO formula, NOT a trained ML model.
// When a Python FastAPI service exists, set VITE_API_URL and implement:
//   GET  /predictions/demand      -> same shape as demoDemand()
//   GET  /predictions/priorities  -> { priorities: [...], matches: [...] } (same shape as demoPriorities())
//   POST /predictions/refresh     -> triggers re-computation, returns { ok: true }
// If the API call fails, the page falls back to the demo calculation and shows a warning.
import { request, USE_MOCK } from './api'
import { hoursUntil, isExpired } from '../utils/calculations'
import { CATEGORIES, LOCATIONS } from '../data/constants'

const wait = (ms) => new Promise((r) => setTimeout(r, ms))
const isOpen = (r) => ['Pending', 'Approved'].includes(r.status)
const matchingPackages = (db, request) =>
  db.packages.filter((p) => p.category === request.category && !isExpired(p) && p.availableServings > 0)

// ---------- demo demand forecast ----------
// forecast(day) = (0.6 x average of last 7 days + 0.4 x average of the same weekday) x (1 + 0.15 x urgency index)
// urgency index = share of open requests that are High or Critical.
export function demoDemand(db) {
  const hist = db.demandHistory
  const avg7 = hist.slice(-7).reduce((s, d) => s + d.meals, 0) / 7
  const open = db.requests.filter(isOpen)
  const urgencyIndex = open.length ? open.filter((r) => ['High', 'Critical'].includes(r.urgency)).length / open.length : 0
  const multiplier = 1 + 0.15 * urgencyIndex

  const forecast = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(Date.now() + (i + 1) * 24 * 3600 * 1000)
    const sameDay = hist.filter((h) => new Date(h.date).getUTCDay() === d.getUTCDay())
    const dayAvg = sameDay.length ? sameDay.reduce((s, h) => s + h.meals, 0) / sameDay.length : avg7
    return { date: d.toISOString().slice(0, 10), predicted: Math.round((0.6 * avg7 + 0.4 * dayAvg) * multiplier) }
  })
  const total = forecast.reduce((s, f) => s + f.predicted, 0)

  const chart = [
    ...hist.map((h) => ({ date: h.date, actual: h.meals })),
    ...forecast,
  ].map((p, i, arr) => ({
    ...p,
    label: new Date(p.date).toLocaleDateString('en-IN', { day: '2-digit', month: 'short' }),
    // repeat the last actual value as predicted so the two lines join
    predicted: i === hist.length - 1 ? p.actual : p.predicted,
  }))

  // Split the weekly total by category / location: 80% history share + 20% share of open requests.
  const split = (names, histKey, openKey) => {
    const histTotals = Object.fromEntries(names.map((n) => [n, hist.reduce((s, h) => s + (h[histKey][n] || 0), 0)]))
    const histSum = Object.values(histTotals).reduce((a, b) => a + b, 0) || 1
    const openTotals = Object.fromEntries(names.map((n) => [n, open.filter((r) => r[openKey] === n).reduce((s, r) => s + r.quantity, 0)]))
    const openSum = Object.values(openTotals).reduce((a, b) => a + b, 0) || 1
    return names
      .map((n) => {
        const share = 0.8 * (histTotals[n] / histSum) + 0.2 * (openTotals[n] / openSum)
        return { name: n, predicted: Math.round(total * share), openRequests: open.filter((r) => r[openKey] === n).length }
      })
      .sort((a, b) => b.predicted - a.predicted)
  }
  const byCategory = split(CATEGORIES, 'categories', 'category')
  const byLocation = split(LOCATIONS, 'locations', 'location').map((l) => {
    const supply = db.packages.filter((p) => p.location === l.name && !isExpired(p)).reduce((s, p) => s + p.availableServings, 0)
    return { ...l, supply, gap: l.predicted - supply }
  })

  return {
    forecast, chart, total, byCategory, byLocation,
    highDemandLocations: byLocation.slice(0, 3),
    method: 'Demo forecast: blended 7-day average and same-weekday average, scaled by the share of urgent open requests.',
    generatedAt: new Date().toISOString(),
  }
}

// ---------- demo priority score (0-100) ----------
const URGENCY_WEIGHT = { Low: 0.25, Medium: 0.5, High: 0.8, Critical: 1 }

export function scoreRequest(db, request) {
  const hoursLeft = hoursUntil(request.neededBy)
  const matches = matchingPackages(db, request)
  const matchServings = matches.reduce((s, p) => s + p.availableServings, 0)
  const soonestExpiry = matches.length ? Math.min(...matches.map((p) => hoursUntil(p.expiresAt))) : null

  const timeRatio = hoursLeft <= 6 ? 1 : hoursLeft <= 24 ? 0.8 : hoursLeft <= 48 ? 0.5 : hoursLeft <= 96 ? 0.25 : 0.1
  const expiryRatio = soonestExpiry === null ? 0 : soonestExpiry <= 6 ? 1 : soonestExpiry <= 24 ? 0.6 : 0.2
  const availRatio = Math.min(1, matchServings / request.quantity)

  const factors = [
    { key: 'urgency', label: 'Request urgency', max: 35, points: Math.round(URGENCY_WEIGHT[request.urgency] * 35), detail: `${request.urgency} urgency` },
    { key: 'beneficiaries', label: 'Beneficiaries', max: 20, points: Math.round(Math.min(request.beneficiaries / 300, 1) * 20), detail: `${request.beneficiaries} people (full marks at 300+)` },
    { key: 'time', label: 'Time remaining', max: 25, points: Math.round(timeRatio * 25), detail: hoursLeft <= 0 ? 'Needed time has passed' : `Needed in ${hoursLeft < 1 ? '<1' : Math.round(hoursLeft)} h` },
    { key: 'availability', label: 'Matching food available', max: 10, points: Math.round(availRatio * 10), detail: matchServings ? `${matchServings} matching servings in stock` : 'No matching food in stock' },
    { key: 'expiry', label: 'Food expiry', max: 10, points: Math.round(expiryRatio * 10), detail: soonestExpiry === null ? 'No matching package' : `Best match expires in ${Math.max(0, Math.round(soonestExpiry))} h` },
  ]
  const score = Math.min(100, factors.reduce((s, f) => s + f.points, 0))
  const level = score >= 75 ? 'Critical' : score >= 55 ? 'High' : score >= 35 ? 'Medium' : 'Low'
  return { requestId: request.id, score, level, factors, hoursLeft, matchServings }
}

export function demoPriorities(db) {
  const open = db.requests.filter(isOpen)
  const priorities = open.map((r) => scoreRequest(db, r)).sort((a, b) => b.score - a.score)

  // Greedy matching: highest priority first, tracking servings already promised so food is never double-counted.
  const remaining = Object.fromEntries(db.packages.map((p) => [p.id, p.availableServings]))
  const ngoById = Object.fromEntries(db.ngos.map((n) => [n.id, n]))
  const matches = []
  priorities.forEach((pr) => {
    const r = open.find((x) => x.id === pr.requestId)
    const ngo = ngoById[r.ngoId]
    if (ngo.verification !== 'Verified') {
      matches.push({ requestId: r.id, score: pr.score, packageId: null, servings: 0, reason: `${ngo.name} is not verified yet, so food cannot be assigned.` })
      return
    }
    const candidates = matchingPackages(db, r)
      .filter((p) => remaining[p.id] > 0)
      // prefer the package that can cover most of the request, then same area, then soonest expiry
      .sort((a, b) => Math.min(remaining[b.id], r.quantity) - Math.min(remaining[a.id], r.quantity)
        || Number(b.location === r.location) - Number(a.location === r.location)
        || hoursUntil(a.expiresAt) - hoursUntil(b.expiresAt))
    const best = candidates[0]
    if (!best) {
      matches.push({ requestId: r.id, score: pr.score, packageId: null, servings: 0, reason: `No ${r.category} in stock right now. Ask donors for this category.` })
      return
    }
    const servings = Math.min(remaining[best.id], r.quantity)
    remaining[best.id] -= servings
    matches.push({
      requestId: r.id, score: pr.score, packageId: best.id, servings,
      reason: `${best.location === r.location ? 'Same area, ' : ''}${best.name} expires in ${Math.max(0, Math.round(hoursUntil(best.expiresAt)))} h.`,
    })
  })
  return { priorities, matches, generatedAt: new Date().toISOString() }
}

// ---------- public API used by the page ----------
async function viaApi(method, path, body, fallback) {
  if (USE_MOCK) {
    await wait(600)
    return { ...fallback(), source: 'demo' }
  }
  try {
    const data = await request(method, path, body)
    return { ...data, source: 'api' }
  } catch {
    return { ...fallback(), source: 'demo-fallback' }
  }
}

export const predictionService = {
  getDemand: (db) => viaApi('GET', '/predictions/demand', undefined, () => demoDemand(db)),
  getPriorities: (db) => viaApi('GET', '/predictions/priorities', undefined, () => demoPriorities(db)),
  async refresh(db) {
    if (!USE_MOCK) {
      try {
        await request('POST', '/predictions/refresh')
      } catch {
        /* the GET calls below will fall back to demo data */
      }
    }
    const [demand, priorities] = await Promise.all([this.getDemand(db), this.getPriorities(db)])
    return { demand, priorities }
  },
}
