// Settings, notification and report-support endpoints.
// Notifications would come from a separate notification service (e.g. fed by Kafka events).
import { api } from './api'
export const settingsService = {
  get: () => api.get('/settings'),
  save: (s) => api.put('/settings', s),
  meta: () => api.get('/meta'),
  reset: () => api.post('/reset'),
  notifications: () => api.get('/notifications'),
  markRead: (id) => api.patch(`/notifications/${id}/read`),
  markAllRead: () => api.patch('/notifications/read-all'),
}
