// Donation / inventory service -> future endpoints: GET/POST /packages, PUT/DELETE /packages/{id}
import { api } from './api'
export const donationService = {
  list: () => api.get('/packages'),
  create: (pkg) => api.post('/packages', pkg),
  update: (id, pkg) => api.put(`/packages/${id}`, pkg),
  remove: (id) => api.del(`/packages/${id}`),
}
