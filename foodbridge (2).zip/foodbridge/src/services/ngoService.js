// NGO service -> future endpoints: GET/POST /ngos, PUT /ngos/{id}
import { api } from './api'
export const ngoService = {
  list: () => api.get('/ngos'),
  create: (ngo) => api.post('/ngos', ngo),
  update: (id, ngo) => api.put(`/ngos/${id}`, ngo),
}
