// Request management service -> future endpoints: GET/POST /requests, PATCH /requests/{id}/status
import { api } from './api'
export const requestService = {
  list: () => api.get('/requests'),
  create: (r) => api.post('/requests', r),
  setStatus: (id, status) => api.patch(`/requests/${id}/status`, { status }),
}
