// Donor service -> future endpoints: GET/POST /donors, PUT /donors/{id}
import { api } from './api'
export const donorService = {
  list: () => api.get('/donors'),
  create: (donor) => api.post('/donors', donor),
  update: (id, donor) => api.put(`/donors/${id}`, donor),
}
