// Auth service. DEMO ONLY: the mock backend compares plain-text passwords.
// A real backend should return a signed JWT from POST /auth/login and store only password hashes.
import { api, setToken } from './api'
export const authService = {
  async login(email, password) {
    const { token, user } = await api.post('/auth/login', { email, password })
    setToken(token)
    return user
  },
  async register(payload) {
    const { token, user } = await api.post('/auth/register', payload)
    setToken(token)
    return user
  },
  logout: () => setToken(null),
}
