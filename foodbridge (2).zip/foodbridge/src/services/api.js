// Central API client. Every service goes through request() so switching to a real backend
// means changing ONE file (or just setting VITE_API_URL).
//
//   .env file:  VITE_API_URL=http://localhost:8000/api
//
// - If VITE_API_URL is empty -> requests are answered by services/mockBackend.js (localStorage).
// - If VITE_API_URL is set   -> requests go to the real backend with a JWT in the Authorization header.
import { handle } from './mockBackend'

export const API_BASE_URL = (import.meta.env.VITE_API_URL || '').replace(/\/$/, '')
export const USE_MOCK = !API_BASE_URL
export const TOKEN_KEY = 'foodbridge.token'

export const getToken = () => localStorage.getItem(TOKEN_KEY)
export const setToken = (t) => (t ? localStorage.setItem(TOKEN_KEY, t) : localStorage.removeItem(TOKEN_KEY))

const wait = (ms) => new Promise((r) => setTimeout(r, ms))

export async function request(method, path, body) {
  if (USE_MOCK) {
    await wait(120) // small delay so loading states are visible
    return structuredClone(handle(method, path, body))
  }
  const res = await fetch(`${API_BASE_URL}${path}`, {
    method,
    headers: {
      'Content-Type': 'application/json',
      ...(getToken() ? { Authorization: `Bearer ${getToken()}` } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  })
  const data = await res.json().catch(() => ({}))
  if (!res.ok) {
    // FastAPI returns { detail: "..." } for errors
    const err = new Error(typeof data.detail === 'string' ? data.detail : 'Request failed')
    err.status = res.status
    throw err
  }
  return data
}

export const api = {
  get: (p) => request('GET', p),
  post: (p, b) => request('POST', p, b),
  put: (p, b) => request('PUT', p, b),
  patch: (p, b) => request('PATCH', p, b),
  del: (p) => request('DELETE', p),
}
