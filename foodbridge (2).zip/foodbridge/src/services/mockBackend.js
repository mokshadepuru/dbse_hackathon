// A tiny in-browser "backend". It plays the role of the future FastAPI / Express / Spring Boot service:
//  - data lives in localStorage (one key), organised in tables with primary and foreign keys
//  - multi-step changes (assign a package, deliver an order) are done as ONE transaction
//  - business rules throw errors, just like an API would return 4xx responses
// When VITE_API_URL is set, api.js skips this file and calls the real backend instead.
import { buildSeed } from '../data/mockData'
import { ASSIGNMENT_STATUSES } from '../data/constants'

const KEY = 'foodbridge.db.v1'
let db = null

function load() {
  if (db) return db
  try {
    const raw = localStorage.getItem(KEY)
    db = raw ? JSON.parse(raw) : null
  } catch {
    db = null
  }
  if (!db) {
    db = buildSeed()
    save()
  }
  return db
}
function save() {
  try {
    localStorage.setItem(KEY, JSON.stringify(db))
  } catch {
    /* storage full or blocked: the app still works for this session */
  }
}

const fail = (message, status = 400) => {
  const e = new Error(message)
  e.status = status
  throw e
}
const nextId = (prefix, rows, start, pad = 3) => {
  const max = rows.reduce((m, r) => Math.max(m, parseInt(r.id.split('-')[1], 10) || 0), start - 1)
  return `${prefix}-${String(max + 1).padStart(pad, '0')}`
}
const find = (table, id) => load()[table].find((r) => r.id === id)
const notify = (type, title, message) => {
  db.notifications.unshift({ id: `NT-${Date.now()}-${Math.floor(Math.random() * 99)}`, type, title, message, createdAt: new Date().toISOString(), read: false })
  db.notifications = db.notifications.slice(0, 60)
}
const isExpired = (p) => new Date(p.expiresAt).getTime() <= Date.now()

// ---------- generic CRUD for simple tables ----------
const TABLES = {
  donors: { prefix: 'D', start: 1, pad: 3 },
  ngos: { prefix: 'N', start: 1, pad: 3 },
  packages: { prefix: 'P', start: 1, pad: 3 },
  requests: { prefix: 'R', start: 1001, pad: 4 },
}

function createRow(table, body) {
  const t = TABLES[table]
  const row = { ...body, id: nextId(t.prefix, db[table], t.start, t.pad) }
  if (table === 'packages') {
    row.availableServings = Number(row.servings)
    row.createdAt = new Date().toISOString()
    if (isExpired(row)) fail('Expiry time must be in the future.')
  }
  if (table === 'requests') {
    row.status = 'Pending'
    row.createdAt = new Date().toISOString()
    const ngo = find('ngos', row.ngoId)
    if (!ngo) fail('NGO not found.', 404)
    notify('request', 'New request received', `${ngo.name} requested ${row.quantity} servings of ${row.category} (${row.urgency}).`)
  }
  if (table === 'donors') row.registeredOn = row.registeredOn || new Date().toISOString().slice(0, 10)
  db[table].unshift(row)
  save()
  return row
}

function updateRow(table, id, body) {
  const row = find(table, id)
  if (!row) fail(`${table} record ${id} not found.`, 404)
  if (table === 'packages' && body.servings !== undefined) {
    // keep "assigned" servings unchanged when the donor edits the total
    const assigned = row.servings - row.availableServings
    if (Number(body.servings) < assigned) fail(`${assigned} servings are already assigned, so total servings cannot go below that.`)
    body.availableServings = Number(body.servings) - assigned
  }
  Object.assign(row, body, { id })
  save()
  return row
}

function deleteRow(table, id) {
  const row = find(table, id)
  if (!row) fail('Record not found.', 404)
  if (table === 'packages' && db.assignments.some((a) => a.packageId === id)) {
    fail('This package already has assignments, so it cannot be deleted (foreign key constraint).', 409)
  }
  db[table] = db[table].filter((r) => r.id !== id)
  save()
  return { deleted: id }
}

// ---------- business transactions ----------
function setRequestStatus(id, status) {
  const r = find('requests', id)
  if (!r) fail('Request not found.', 404)
  const allowed = { Pending: ['Approved', 'Rejected'], Approved: ['Rejected', 'Pending'], Rejected: ['Pending'] }
  if (!(allowed[r.status] || []).includes(status)) fail(`A ${r.status} request cannot be changed to ${status} manually.`)
  r.status = status
  if (status === 'Approved') notify('approved', 'Request approved', `${r.id} was approved.`)
  save()
  return r
}

function createAssignment(body) {
  const { packageId, requestId, volunteerId, pickupAt } = body
  const servings = Number(body.servings)
  const pkg = find('packages', packageId)
  const request = find('requests', requestId)
  if (!pkg || !request) fail('Package or request not found.', 404)
  const ngo = find('ngos', request.ngoId)
  if (isExpired(pkg)) fail('This package has expired and cannot be assigned.')
  if (pkg.availableServings <= 0) fail('This package has no servings left.')
  if (!['Pending', 'Approved'].includes(request.status)) fail(`Request ${request.id} is ${request.status} and cannot receive a new assignment.`)
  if (db.assignments.some((a) => a.requestId === requestId && a.status !== 'Delivered')) fail('This request already has an active assignment.', 409)
  if (ngo.verification !== 'Verified') fail(`${ngo.name} is not verified yet, so it cannot receive food.`)
  if (pkg.category !== request.category) fail(`Category mismatch: package is ${pkg.category}, request needs ${request.category}.`)
  if (!Number.isInteger(servings) || servings < 1) fail('Assigned quantity must be a whole number of at least 1.')
  if (servings > pkg.availableServings) fail(`Only ${pkg.availableServings} servings are available in this package.`)
  if (servings > request.quantity) fail(`The request only needs ${request.quantity} servings.`)
  if (!volunteerId || !find('volunteers', volunteerId)) fail('Choose a volunteer or delivery partner.')
  if (!pickupAt) fail('Choose a pickup date and time.')

  const donor = find('donors', pkg.donorId)
  pkg.availableServings -= servings
  request.status = 'Assigned'
  const row = {
    id: nextId('A', db.assignments, 5001, 4), packageId, requestId, donorId: donor.id, ngoId: ngo.id, servings,
    pickupLocation: `${pkg.location}`, destination: `${ngo.name}, ${ngo.address}`,
    pickupAt: new Date(pickupAt).toISOString(), volunteerId, status: 'Assigned',
    createdAt: new Date().toISOString(), deliveredAt: null,
  }
  db.assignments.unshift(row)
  notify('assignment', 'New assignment', `${row.id}: ${servings} servings from ${donor.organization} to ${ngo.name}.`)
  save()
  return row
}

function setAssignmentStatus(id, status) {
  const a = find('assignments', id)
  if (!a) fail('Assignment not found.', 404)
  const from = ASSIGNMENT_STATUSES.indexOf(a.status)
  const to = ASSIGNMENT_STATUSES.indexOf(status)
  if (to !== from + 1) fail(`Status must move one step at a time: ${a.status} → ${ASSIGNMENT_STATUSES[from + 1] || 'no further step'}.`)
  const request = find('requests', a.requestId)
  const ngo = find('ngos', a.ngoId)
  a.status = status
  if (status === 'In Transit') request.status = 'In Transit'
  if (status === 'Delivered') {
    a.deliveredAt = new Date().toISOString()
    request.status = 'Delivered'
    db.distributions.unshift({
      id: nextId('H', db.distributions, 9001, 4), assignmentId: a.id, packageId: a.packageId, donorId: a.donorId, ngoId: a.ngoId,
      servings: a.servings, mealsServed: a.servings, deliveredAt: a.deliveredAt, status: 'Completed',
    })
    notify('delivered', 'Delivery completed', `${a.servings} servings reached ${ngo.name}.`)
  } else {
    notify('assignment', 'Assignment update', `${a.id} is now ${status}.`)
  }
  save()
  return a
}

function cancelAssignment(id) {
  const a = find('assignments', id)
  if (!a) fail('Assignment not found.', 404)
  if (a.status !== 'Assigned') fail('Only assignments that have not been picked up can be cancelled.')
  find('packages', a.packageId).availableServings += a.servings
  find('requests', a.requestId).status = 'Approved'
  db.assignments = db.assignments.filter((x) => x.id !== id)
  notify('assignment', 'Assignment cancelled', `${id} was cancelled and the food returned to inventory.`)
  save()
  return { deleted: id }
}

// ---------- auth (DEMO ONLY: plain-text passwords, fake token) ----------
function login({ email, password }) {
  const u = load().users.find((x) => x.email.toLowerCase() === String(email).toLowerCase())
  if (!u || u.password !== password) fail('Incorrect email or password.', 401)
  const { password: _pw, ...user } = u
  return { token: `demo-token-${u.id}`, user }
}
function register(body) {
  load()
  if (db.users.some((u) => u.email.toLowerCase() === body.email.toLowerCase())) fail('An account with this email already exists.', 409)
  let linkedId = null
  if (body.role === 'Donor') {
    linkedId = createRow('donors', { name: body.name, organization: body.organization || 'Individual donor', type: 'Individual', phone: body.phone || '', email: body.email, location: 'Madhapur', address: '', status: 'Active' }).id
  } else if (body.role === 'NGO') {
    linkedId = createRow('ngos', { name: body.organization || body.name, verification: 'Pending', contactPerson: body.name, phone: body.phone || '', email: body.email, address: '', serviceArea: 'Ameerpet', beneficiaries: 0, requirements: [], capacity: 0 }).id
  } else if (body.role === 'Volunteer') {
    linkedId = `V-${String(db.volunteers.length + 1).padStart(2, '0')}`
    db.volunteers.push({ id: linkedId, name: body.name, phone: body.phone || '', vehicle: 'Motorbike', area: 'Ameerpet', available: true })
  }
  const user = { id: nextId('U', db.users, 1), name: body.name, email: body.email, password: body.password, role: body.role, linkedId }
  db.users.push(user)
  save()
  const { password: _pw, ...safe } = user
  return { token: `demo-token-${user.id}`, user: safe }
}

// ---------- router ----------
export function handle(method, path, body = {}) {
  load()
  const parts = path.replace(/^\/+/, '').split('/')
  const [res, id, action] = parts

  if (res === 'auth' && id === 'login') return login(body)
  if (res === 'auth' && id === 'register') return register(body)
  if (res === 'reset' && method === 'POST') {
    // fresh sample data, but keep accounts registered in this browser (and the records they own)
    const seedIds = new Set(buildSeed().users.map((u) => u.id))
    const extraUsers = db.users.filter((u) => !seedIds.has(u.id))
    const keep = { donors: [], ngos: [], volunteers: [] }
    extraUsers.forEach((u) => {
      const table = { Donor: 'donors', NGO: 'ngos', Volunteer: 'volunteers' }[u.role]
      const rec = table && db[table].find((r) => r.id === u.linkedId)
      if (rec) keep[table].push(rec)
    })
    db = buildSeed()
    db.users.push(...extraUsers)
    Object.keys(keep).forEach((t) => db[t].push(...keep[t]))
    save()
    return { ok: true }
  }
  if (res === 'meta') return { activityHistory: db.activityHistory, demandHistory: db.demandHistory, monthlyHistory: db.monthlyHistory }
  if (res === 'settings') {
    if (method === 'PUT') {
      db.settings = { ...db.settings, ...body }
      save()
    }
    return db.settings
  }
  if (res === 'notifications') {
    if (id === 'read-all') db.notifications.forEach((n) => (n.read = true))
    else if (id) find('notifications', id).read = true
    save()
    return db.notifications
  }
  if (res === 'volunteers') return db.volunteers
  if (res === 'distributions') return db.distributions
  if (res === 'assignments') {
    if (method === 'GET') return db.assignments
    if (method === 'POST') return createAssignment(body)
    if (method === 'PATCH' && action === 'status') return setAssignmentStatus(id, body.status)
    if (method === 'DELETE') return cancelAssignment(id)
  }
  if (res === 'requests' && method === 'PATCH' && action === 'status') return setRequestStatus(id, body.status)
  if (TABLES[res]) {
    if (method === 'GET') return db[res]
    if (method === 'POST') return createRow(res, body)
    if (method === 'PUT') return updateRow(res, id, body)
    if (method === 'DELETE') return deleteRow(res, id)
  }
  return fail(`No mock route for ${method} /${path}`, 404)
}
