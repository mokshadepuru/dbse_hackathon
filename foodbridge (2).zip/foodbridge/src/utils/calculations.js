// Pure helper functions: no React and no storage, so they are easy to read and test.
import { KG_PER_MEAL, EXPIRING_SOON_HOURS } from '../data/constants'

const HOUR = 3600 * 1000
export const hoursUntil = (isoString) => (new Date(isoString).getTime() - Date.now()) / HOUR
export const isExpired = (pkg) => hoursUntil(pkg.expiresAt) <= 0

// Package availability is derived from data, so it can never get out of sync.
export function packageStatus(pkg) {
  if (isExpired(pkg)) return 'Expired'
  if (pkg.availableServings <= 0) return 'Fully assigned'
  return 'Available'
}
export const isRequestable = (pkg) => packageStatus(pkg) === 'Available'
export const isExpiringSoon = (pkg, windowHours = EXPIRING_SOON_HOURS) =>
  isRequestable(pkg) && hoursUntil(pkg.expiresAt) <= windowHours

export const servingsToKg = (servings) => Math.round(servings * KG_PER_MEAL)

// ---------- formatting ----------
export const fmtDateTime = (iso) =>
  iso ? new Date(iso).toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }) : '-'
export const fmtDate = (iso) =>
  iso ? new Date(iso).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }) : '-'
export const fmtNumber = (n) => Number(n || 0).toLocaleString('en-IN')
export function timeLeft(iso) {
  const h = hoursUntil(iso)
  const abs = Math.abs(h)
  const text = abs < 1 ? `${Math.max(1, Math.round(abs * 60))} min` : abs < 48 ? `${Math.round(abs)} h` : `${Math.round(abs / 24)} days`
  return h >= 0 ? `in ${text}` : `${text} ago`
}
// value for <input type="datetime-local">
export const toLocalInput = (iso) => {
  const d = new Date(iso || Date.now())
  d.setMinutes(d.getMinutes() - d.getTimezoneOffset())
  return d.toISOString().slice(0, 16)
}
export const monthLabel = (offsetFromNow) => {
  const d = new Date()
  d.setDate(1)
  d.setMonth(d.getMonth() + offsetFromNow)
  return d.toLocaleString('en-IN', { month: 'short' })
}

// ---------- dashboard / analytics numbers ----------
const OPEN_STATUSES = ['Pending', 'Approved']
const ACTIVE_STATUSES = ['Pending', 'Approved', 'Assigned', 'In Transit']

export function monthlySeries(db) {
  const n = db.monthlyHistory.length
  const liveDonations = db.packages.length
  const liveMeals = db.distributions.reduce((s, d) => s + d.mealsServed, 0)
  return db.monthlyHistory.map((m, i) => {
    const current = i === n - 1
    const donations = m.donations + (current ? liveDonations : 0)
    const meals = m.distributedMeals + (current ? liveMeals : 0)
    return { month: monthLabel(i - (n - 1)), donations, meals, kg: servingsToKg(meals) }
  })
}

export function computeMetrics(db) {
  const months = monthlySeries(db)
  const meals = months.reduce((s, m) => s + m.meals, 0)
  const requestsForCompletion = db.requests.filter((r) => r.status !== 'Rejected')
  const delivered = db.requests.filter((r) => r.status === 'Delivered').length
  return {
    totalDonations: months.reduce((s, m) => s + m.donations, 0),
    availablePackages: db.packages.filter((p) => packageStatus(p) === 'Available').length,
    activeRequests: db.requests.filter((r) => ACTIVE_STATUSES.includes(r.status)).length,
    pendingAssignments: db.requests.filter((r) => OPEN_STATUSES.includes(r.status)).length,
    mealsDistributed: meals,
    wastePreventedKg: servingsToKg(meals),
    activeDonors: db.donors.filter((d) => d.status === 'Active').length,
    verifiedNgos: db.ngos.filter((n) => n.verification === 'Verified').length,
    completionRate: requestsForCompletion.length ? Math.round((delivered / requestsForCompletion.length) * 100) : 0,
    expiringSoon: db.packages.filter((p) => isExpiringSoon(p, db.settings.expiryWindowHours)).length,
  }
}

// Last N days of activity. History comes from seed data; "today" is calculated from live records.
export function dailySeries(db, days) {
  const history = db.activityHistory.slice(-(days - 1))
  const today = new Date().toDateString()
  const donations = db.packages.filter((p) => new Date(p.createdAt).toDateString() === today).length
  const meals = db.distributions.filter((d) => new Date(d.deliveredAt).toDateString() === today).reduce((s, d) => s + d.mealsServed, 0)
  return [...history, { date: new Date().toISOString().slice(0, 10), donations, meals }].map((d) => ({
    ...d,
    label: new Date(d.date).toLocaleDateString('en-IN', { day: '2-digit', month: 'short' }),
  }))
}

// Where did all listed food go? Delivered / on the way / still available / expired unused.
export function foodFlow(db) {
  const delivered = db.distributions.reduce((s, d) => s + d.servings, 0)
  const onTheWay = db.assignments.filter((a) => a.status !== 'Delivered').reduce((s, a) => s + a.servings, 0)
  const available = db.packages.filter((p) => !isExpired(p)).reduce((s, p) => s + p.availableServings, 0)
  const expired = db.packages.filter(isExpired).reduce((s, p) => s + p.availableServings, 0)
  return [
    { name: 'Delivered', value: delivered, color: '#176B45' },
    { name: 'Assigned / in transit', value: onTheWay, color: '#5FB487' },
    { name: 'Available now', value: available, color: '#F59E0B' },
    { name: 'Expired unused', value: expired, color: '#DC2626' },
  ].filter((x) => x.value > 0)
}

export function categoryDistribution(db) {
  const map = {}
  db.packages.forEach((p) => (map[p.category] = (map[p.category] || 0) + p.servings))
  return Object.entries(map).map(([name, value]) => ({ name, value }))
}

// Look up names from foreign keys (like a SQL JOIN)
export const byId = (rows) => Object.fromEntries(rows.map((r) => [r.id, r]))
