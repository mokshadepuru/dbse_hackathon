import { Area, AreaChart, Bar, BarChart, CartesianGrid, Cell, Legend, Line, LineChart, Pie, PieChart, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { CHART_COLORS, axisProps, tooltipStyle } from './ChartCard'

export function ActivityAreaChart({ data }) {
  return (
    <ResponsiveContainer>
      <AreaChart data={data} margin={{ left: -15, right: 8, top: 8 }}>
        <defs>
          <linearGradient id="gDon" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#176B45" stopOpacity={0.25} />
            <stop offset="100%" stopColor="#176B45" stopOpacity={0} />
          </linearGradient>
        </defs>
        <CartesianGrid stroke="#EEF2EF" vertical={false} />
        <XAxis dataKey="label" {...axisProps} interval="preserveStartEnd" minTickGap={24} />
        <YAxis {...axisProps} allowDecimals={false} />
        <Tooltip contentStyle={tooltipStyle} />
        <Area type="monotone" dataKey="donations" name="Donations" stroke="#176B45" strokeWidth={2} fill="url(#gDon)" />
      </AreaChart>
    </ResponsiveContainer>
  )
}

export function DonutChart({ data }) {
  return (
    <ResponsiveContainer>
      <PieChart>
        <Pie data={data} dataKey="value" nameKey="name" innerRadius="58%" outerRadius="85%" paddingAngle={2}>
          {data.map((d, i) => <Cell key={d.name} fill={d.color || CHART_COLORS[i % CHART_COLORS.length]} />)}
        </Pie>
        <Tooltip contentStyle={tooltipStyle} formatter={(v) => `${v} servings`} />
        <Legend iconType="circle" wrapperStyle={{ fontSize: 12 }} />
      </PieChart>
    </ResponsiveContainer>
  )
}

export function MonthlyBarChart({ data, bars }) {
  return (
    <ResponsiveContainer>
      <BarChart data={data} margin={{ left: -10, right: 8, top: 8 }}>
        <CartesianGrid stroke="#EEF2EF" vertical={false} />
        <XAxis dataKey="month" {...axisProps} />
        <YAxis {...axisProps} />
        <Tooltip contentStyle={tooltipStyle} />
        <Legend wrapperStyle={{ fontSize: 12 }} />
        {bars.map((b, i) => <Bar key={b.key} dataKey={b.key} name={b.name} fill={b.color || CHART_COLORS[i]} radius={[6, 6, 0, 0]} />)}
      </BarChart>
    </ResponsiveContainer>
  )
}

export function HorizontalBars({ data, dataKey = 'predicted', nameKey = 'name', color = '#176B45' }) {
  return (
    <ResponsiveContainer>
      <BarChart data={data} layout="vertical" margin={{ left: 20, right: 16 }}>
        <CartesianGrid stroke="#EEF2EF" horizontal={false} />
        <XAxis type="number" {...axisProps} />
        <YAxis type="category" dataKey={nameKey} width={120} {...axisProps} />
        <Tooltip contentStyle={tooltipStyle} />
        <Bar dataKey={dataKey} name="Predicted meals" fill={color} radius={[0, 6, 6, 0]} />
      </BarChart>
    </ResponsiveContainer>
  )
}

export function ForecastLineChart({ data, splitLabel }) {
  return (
    <ResponsiveContainer>
      <LineChart data={data} margin={{ left: -10, right: 24, top: 8 }}>
        <CartesianGrid stroke="#EEF2EF" vertical={false} />
        <XAxis dataKey="label" {...axisProps} interval={1} />
        <YAxis {...axisProps} />
        <Tooltip contentStyle={tooltipStyle} />
        <Legend wrapperStyle={{ fontSize: 12 }} />
        {splitLabel && <ReferenceLine x={splitLabel} stroke="#94A3B8" strokeDasharray="4 4" label={{ value: 'Today', fontSize: 11, fill: '#64748B' }} />}
        <Line type="monotone" dataKey="actual" name="Historical demand" stroke="#176B45" strokeWidth={2.2} dot={false} />
        <Line type="monotone" dataKey="predicted" name="Predicted demand (demo)" stroke="#F59E0B" strokeWidth={2.2} strokeDasharray="6 4" dot={false} />
      </LineChart>
    </ResponsiveContainer>
  )
}
