// Card wrapper for a chart: title, optional controls (filters) on the right, then the chart.
export default function ChartCard({ title, subtitle, controls, children, height = 260 }) {
  return (
    <section className="card chart-card">
      <div className="card-head">
        <div>
          <h3>{title}</h3>
          {subtitle && <p className="muted small">{subtitle}</p>}
        </div>
        {controls}
      </div>
      <div style={{ width: '100%', height }}>{children}</div>
    </section>
  )
}

export function RangeToggle({ value, onChange, options }) {
  return (
    <div className="segmented" role="group" aria-label="Chart range">
      {options.map((o) => (
        <button key={o.value} className={value === o.value ? 'on' : ''} onClick={() => onChange(o.value)} aria-pressed={value === o.value}>{o.label}</button>
      ))}
    </div>
  )
}

export const CHART_COLORS = ['#176B45', '#5FB487', '#F59E0B', '#2563EB', '#DC2626', '#7C3AED']
export const axisProps = { tick: { fontSize: 12, fill: '#64748B' }, tickLine: false, axisLine: { stroke: '#E2E8E5' } }
export const tooltipStyle = { borderRadius: 10, border: '1px solid #E2E8E5', fontSize: 13 }
