import { useEffect, useMemo, useRef, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { Menu, Search } from 'lucide-react'
import { useApp } from '../../context/AppContext'
import { NAV_ITEMS } from './navConfig'
import NotificationPanel from './NotificationPanel'

// Global search looks across packages, donors, NGOs and requests and jumps to the right page.
function GlobalSearch() {
  const { db, user } = useApp()
  const nav = useNavigate()
  const [q, setQ] = useState('')
  const [open, setOpen] = useState(false)
  const ref = useRef(null)

  const results = useMemo(() => {
    const t = q.trim().toLowerCase()
    if (t.length < 2) return []
    const ngoName = (id) => db.ngos.find((n) => n.id === id)?.name || ''
    const all = [
      ...db.packages.map((p) => ({ id: p.id, label: p.name, kind: 'Package', to: '/packages', text: `${p.name} ${p.category} ${p.location}`, roles: ['Admin', 'Donor', 'NGO'] })),
      ...db.donors.map((d) => ({ id: d.id, label: d.organization, kind: 'Donor', to: '/donors', text: `${d.name} ${d.organization} ${d.location}`, roles: ['Admin'] })),
      ...db.ngos.map((n) => ({ id: n.id, label: n.name, kind: 'NGO', to: '/ngos', text: `${n.name} ${n.contactPerson} ${n.serviceArea}`, roles: ['Admin'] })),
      ...db.requests.map((r) => ({ id: r.id, label: `${r.id} - ${ngoName(r.ngoId)}`, kind: 'Request', to: '/requests', text: `${r.id} ${ngoName(r.ngoId)} ${r.category}`, roles: ['Admin', 'NGO'] })),
    ]
    return all.filter((x) => x.roles.includes(user.role) && x.text.toLowerCase().includes(t)).slice(0, 7)
  }, [q, db, user.role])

  useEffect(() => {
    const close = (e) => ref.current && !ref.current.contains(e.target) && setOpen(false)
    document.addEventListener('mousedown', close)
    return () => document.removeEventListener('mousedown', close)
  }, [])

  const go = (r) => {
    nav(`${r.to}?q=${encodeURIComponent(r.id)}`)
    setOpen(false)
    setQ('')
  }
  return (
    <div className="global-search" ref={ref}>
      <Search size={16} aria-hidden="true" />
      <input type="search" value={q} placeholder="Search packages, NGOs, requests..." aria-label="Search the whole app"
        onChange={(e) => { setQ(e.target.value); setOpen(true) }} onFocus={() => setOpen(true)}
        onKeyDown={(e) => e.key === 'Enter' && results[0] && go(results[0])} />
      {open && q.trim().length >= 2 && (
        <div className="popover search-results">
          {results.length === 0 ? <p className="muted pad">No matches for “{q}”.</p> : (
            <ul>{results.map((r) => (
              <li key={r.kind + r.id}><button onClick={() => go(r)}><span className="muted">{r.kind}</span> {r.label}</button></li>
            ))}</ul>
          )}
        </div>
      )}
    </div>
  )
}

export default function Topbar({ onMenu }) {
  const { pathname } = useLocation()
  const { user } = useApp()
  const title = NAV_ITEMS.find((i) => pathname.startsWith(i.to))?.label || 'FoodBridge'
  return (
    <header className="topbar">
      <button className="icon-btn menu-btn" onClick={onMenu} aria-label="Open navigation menu"><Menu size={22} /></button>
      <h2 className="topbar-title">{title}</h2>
      <GlobalSearch />
      <div className="topbar-right">
        <NotificationPanel />
        <div className="profile-chip" title={`${user.name} (${user.role})`}>
          <span className="avatar">{user.name.charAt(0)}</span>
          <span className="profile-text"><strong>{user.name}</strong><span>{user.role}</span></span>
        </div>
      </div>
    </header>
  )
}
