import { useEffect, useRef, useState } from 'react'
import { Bell, CheckCheck, ClipboardList, PackageCheck, ThumbsUp, Timer, Truck } from 'lucide-react'
import { useApp } from '../../context/AppContext'
import { timeLeft } from '../../utils/calculations'

const ICONS = { request: ClipboardList, approved: ThumbsUp, expiry: Timer, assignment: Truck, delivered: PackageCheck }

// Notification centre. Events here are created by the mock backend; in a microservice setup
// a notification service would push them (for example from Kafka topics).
export default function NotificationPanel() {
  const { db, markRead, markAllRead } = useApp()
  const [open, setOpen] = useState(false)
  const ref = useRef(null)
  const unread = db.notifications.filter((n) => !n.read).length

  useEffect(() => {
    const close = (e) => ref.current && !ref.current.contains(e.target) && setOpen(false)
    document.addEventListener('mousedown', close)
    return () => document.removeEventListener('mousedown', close)
  }, [])

  return (
    <div className="popover-wrap" ref={ref}>
      <button className="icon-btn bell" onClick={() => setOpen(!open)} aria-label={`Notifications, ${unread} unread`} aria-expanded={open}>
        <Bell size={20} />
        {unread > 0 && <span className="bell-count">{unread}</span>}
      </button>
      {open && (
        <div className="popover notif" role="dialog" aria-label="Notifications">
          <div className="popover-head">
            <strong>Notifications</strong>
            <button className="link-btn" onClick={markAllRead} disabled={!unread}><CheckCheck size={14} /> Mark all read</button>
          </div>
          <ul>
            {db.notifications.length === 0 && <li className="muted pad">You are all caught up.</li>}
            {db.notifications.slice(0, 12).map((n) => {
              const Icon = ICONS[n.type] || Bell
              return (
                <li key={n.id}>
                  <button className={`notif-item ${n.read ? '' : 'unread'}`} onClick={() => !n.read && markRead(n.id)}>
                    <span className="notif-icon"><Icon size={16} /></span>
                    <span>
                      <strong>{n.title}</strong>
                      <span className="notif-msg">{n.message}</span>
                      <span className="notif-time">{timeLeft(n.createdAt)}</span>
                    </span>
                  </button>
                </li>
              )
            })}
          </ul>
        </div>
      )}
    </div>
  )
}
