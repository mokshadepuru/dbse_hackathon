import { NavLink } from 'react-router-dom'
import { Leaf, LogOut } from 'lucide-react'
import { useApp } from '../../context/AppContext'
import { NAV_ITEMS } from './navConfig'

export default function Sidebar({ open, onClose }) {
  const { user, logout } = useApp()
  const items = NAV_ITEMS.filter((i) => i.roles.includes(user.role))
  return (
    <>
      {open && <div className="sidebar-scrim" onClick={onClose} aria-hidden="true" />}
      <aside className={`sidebar ${open ? 'sidebar-open' : ''}`} aria-label="Main navigation">
        <div className="brand">
          <span className="brand-mark"><Leaf size={20} aria-hidden="true" /></span>
          <span className="brand-name">FoodBridge</span>
        </div>
        <nav>
          {items.map(({ to, label, icon: Icon }) => (
            <NavLink key={to} to={to} onClick={onClose} className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
              <Icon size={18} aria-hidden="true" /> {label}
            </NavLink>
          ))}
        </nav>
        <div className="sidebar-foot">
          <div className="sidebar-user">
            <span className="avatar">{user.name.charAt(0)}</span>
            <div>
              <strong>{user.name}</strong>
              <span>{user.role}</span>
            </div>
          </div>
          <button className="btn btn-ghost btn-block" onClick={logout}><LogOut size={16} /> Log out</button>
        </div>
      </aside>
    </>
  )
}
