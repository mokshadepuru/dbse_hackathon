import { useEffect, useState } from 'react'
import { Outlet, useLocation } from 'react-router-dom'
import Sidebar from './Sidebar'
import Topbar from './Topbar'
import { useApp } from '../../context/AppContext'
import { ErrorState, Loading } from '../common/States'

export default function AppLayout() {
  const [open, setOpen] = useState(false)
  const { db, loading, loadError, reload } = useApp()
  const { pathname } = useLocation()
  useEffect(() => setOpen(false), [pathname])

  return (
    <div className="app">
      <a className="skip-link" href="#main">Skip to content</a>
      <Sidebar open={open} onClose={() => setOpen(false)} />
      <div className="main">
        {db && <Topbar onMenu={() => setOpen(true)} />}
        <main id="main" className="page">
          {loading && !db ? <Loading label="Loading FoodBridge data..." />
            : loadError && !db ? <ErrorState message={`Could not load data: ${loadError}`} onRetry={reload} />
            : <Outlet />}
        </main>
      </div>
    </div>
  )
}
