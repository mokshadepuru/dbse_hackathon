import { BarChart3, BrainCircuit, Building2, ClipboardList, HeartHandshake, History, LayoutDashboard, Package, Settings, Truck } from 'lucide-react'

// roles = who can see the menu item (demo role-aware navigation)
export const NAV_ITEMS = [
  { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard, roles: ['Admin', 'Donor', 'NGO', 'Volunteer'] },
  { to: '/packages', label: 'Food Packages', icon: Package, roles: ['Admin', 'Donor', 'NGO'] },
  { to: '/requests', label: 'NGO Requests', icon: ClipboardList, roles: ['Admin', 'NGO'] },
  { to: '/assignments', label: 'Assignments', icon: Truck, roles: ['Admin', 'Volunteer'] },
  { to: '/history', label: 'Distribution History', icon: History, roles: ['Admin', 'Donor', 'NGO', 'Volunteer'] },
  { to: '/donors', label: 'Donors', icon: HeartHandshake, roles: ['Admin'] },
  { to: '/ngos', label: 'NGOs', icon: Building2, roles: ['Admin'] },
  { to: '/insights', label: 'AI & Demand Insights', icon: BrainCircuit, roles: ['Admin', 'NGO'] },
  { to: '/analytics', label: 'Reports & Analytics', icon: BarChart3, roles: ['Admin'] },
  { to: '/settings', label: 'Settings', icon: Settings, roles: ['Admin', 'Donor', 'NGO', 'Volunteer'] },
]
