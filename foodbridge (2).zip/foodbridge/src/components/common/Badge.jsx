// One place that decides badge colours, so statuses look the same on every page.
const TONES = {
  Active: 'green', Verified: 'green', Available: 'green', Delivered: 'green', Completed: 'green', Approved: 'green', Vegetarian: 'green', Vegan: 'green', Low: 'slate',
  Pending: 'amber', Medium: 'amber', 'Expiring soon': 'amber', 'Picked Up': 'amber', Unverified: 'slate', Inactive: 'slate', 'Fully assigned': 'slate',
  High: 'orange', 'Non-Vegetarian': 'red-soft',
  Critical: 'red', Rejected: 'red', Expired: 'red',
  Assigned: 'teal', 'In Transit': 'blue',
}
export default function Badge({ children, tone }) {
  const t = tone || TONES[children] || 'slate'
  return <span className={`badge badge-${t}`}>{children}</span>
}
