import { CheckCircle2, Info, XCircle, X } from 'lucide-react'
import { useApp } from '../../context/AppContext'

export default function Toasts() {
  const { toasts, dismissToast } = useApp()
  return (
    <div className="toasts" aria-live="polite">
      {toasts.map((t) => (
        <div key={t.id} className={`toast toast-${t.type}`} role={t.type === 'error' ? 'alert' : 'status'}>
          {t.type === 'success' ? <CheckCircle2 size={18} /> : t.type === 'error' ? <XCircle size={18} /> : <Info size={18} />}
          <span>{t.message}</span>
          <button className="icon-btn" onClick={() => dismissToast(t.id)} aria-label="Dismiss message"><X size={14} /></button>
        </div>
      ))}
    </div>
  )
}
