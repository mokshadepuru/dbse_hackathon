export default function StatCard({ icon: Icon, label, value, hint, tone = 'green' }) {
  return (
    <div className="card stat">
      <div className={`stat-icon tone-${tone}`}><Icon size={20} aria-hidden="true" /></div>
      <div>
        <div className="stat-value">{value}</div>
        <div className="stat-label">{label}</div>
        {hint && <div className="stat-hint">{hint}</div>}
      </div>
    </div>
  )
}
