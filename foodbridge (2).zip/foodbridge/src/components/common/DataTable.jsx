import { useMemo, useState } from 'react'
import { ArrowDown, ArrowUp, ChevronLeft, ChevronRight } from 'lucide-react'
import { EmptyState } from './States'

// Reusable table with sorting and pagination.
// columns: [{ key, header, render?(row), sortValue?(row), className? }]
export default function DataTable({ columns, rows, pageSize = 8, defaultSort, emptyTitle = 'Nothing to show', emptyMessage, onRowClick, caption }) {
  const [sort, setSort] = useState(defaultSort || null) // { key, dir }
  const [page, setPage] = useState(1)

  const sorted = useMemo(() => {
    if (!sort) return rows
    const col = columns.find((c) => c.key === sort.key)
    const get = col?.sortValue || ((r) => r[sort.key])
    return [...rows].sort((a, b) => {
      const x = get(a), y = get(b)
      const cmp = typeof x === 'number' && typeof y === 'number' ? x - y : String(x ?? '').localeCompare(String(y ?? ''))
      return sort.dir === 'asc' ? cmp : -cmp
    })
  }, [rows, sort, columns])

  const pages = Math.max(1, Math.ceil(sorted.length / pageSize))
  const current = Math.min(page, pages)
  const visible = sorted.slice((current - 1) * pageSize, current * pageSize)

  const toggleSort = (key) => {
    setPage(1)
    setSort((s) => (s?.key === key ? { key, dir: s.dir === 'asc' ? 'desc' : 'asc' } : { key, dir: 'asc' }))
  }

  if (!rows.length) return <EmptyState title={emptyTitle} message={emptyMessage} />

  return (
    <>
      <div className="table-wrap">
        <table className="table">
          {caption && <caption className="sr-only">{caption}</caption>}
          <thead>
            <tr>
              {columns.map((c) => {
                const sortable = c.sortValue || c.sortable !== false
                const active = sort?.key === c.key
                return (
                  <th key={c.key} className={c.className} aria-sort={active ? (sort.dir === 'asc' ? 'ascending' : 'descending') : 'none'}>
                    {sortable && c.header ? (
                      <button className="th-btn" onClick={() => toggleSort(c.key)}>
                        {c.header}
                        {active && (sort.dir === 'asc' ? <ArrowUp size={13} /> : <ArrowDown size={13} />)}
                      </button>
                    ) : c.header}
                  </th>
                )
              })}
            </tr>
          </thead>
          <tbody>
            {visible.map((row) => (
              <tr key={row.id} className={onRowClick ? 'clickable' : ''} onClick={onRowClick ? () => onRowClick(row) : undefined}>
                {columns.map((c) => (
                  <td key={c.key} className={c.className} data-label={c.header}>{c.render ? c.render(row) : row[c.key]}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {sorted.length > pageSize && (
        <div className="pagination">
          <span className="muted">Showing {(current - 1) * pageSize + 1}-{Math.min(current * pageSize, sorted.length)} of {sorted.length}</span>
          <div className="pagination-btns">
            <button className="icon-btn" disabled={current === 1} onClick={() => setPage(current - 1)} aria-label="Previous page"><ChevronLeft size={16} /></button>
            <span>Page {current} of {pages}</span>
            <button className="icon-btn" disabled={current === pages} onClick={() => setPage(current + 1)} aria-label="Next page"><ChevronRight size={16} /></button>
          </div>
        </div>
      )}
    </>
  )
}
