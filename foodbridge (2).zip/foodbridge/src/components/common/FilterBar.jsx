import { Search } from 'lucide-react'

export function SearchBox({ value, onChange, placeholder = 'Search...', label = 'Search' }) {
  return (
    <label className="search-box">
      <Search size={16} aria-hidden="true" />
      <span className="sr-only">{label}</span>
      <input type="search" value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} />
    </label>
  )
}

export function SelectFilter({ label, value, onChange, options, allLabel }) {
  return (
    <label className="select-filter">
      <span className="sr-only">{label}</span>
      <select value={value} onChange={(e) => onChange(e.target.value)} aria-label={label}>
        <option value="">{allLabel || `All ${label.toLowerCase()}`}</option>
        {options.map((o) => (
          <option key={o.value ?? o} value={o.value ?? o}>{o.label ?? o}</option>
        ))}
      </select>
    </label>
  )
}
