import { AlertTriangle, Inbox, Loader2 } from 'lucide-react'

export function Loading({ label = 'Loading...' }) {
  return (
    <div className="state" role="status">
      <Loader2 className="spin" size={26} aria-hidden="true" />
      <p>{label}</p>
    </div>
  )
}
export function ErrorState({ message, onRetry }) {
  return (
    <div className="state state-error" role="alert">
      <AlertTriangle size={26} aria-hidden="true" />
      <p>{message}</p>
      {onRetry && <button className="btn btn-secondary" onClick={onRetry}>Try again</button>}
    </div>
  )
}
export function EmptyState({ title, message, action }) {
  return (
    <div className="state">
      <Inbox size={28} aria-hidden="true" />
      <h3>{title}</h3>
      {message && <p>{message}</p>}
      {action}
    </div>
  )
}
