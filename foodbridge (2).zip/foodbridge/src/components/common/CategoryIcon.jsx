import { Apple, Croissant, Milk, Package, Soup, Wheat } from 'lucide-react'

const ICONS = {
  'Cooked Meals': Soup,
  'Bakery & Bread': Croissant,
  'Fruits & Vegetables': Apple,
  'Packaged Food': Package,
  'Dairy & Beverages': Milk,
  'Grains & Staples': Wheat,
}
export default function CategoryIcon({ category, size = 22 }) {
  const Icon = ICONS[category] || Package
  return <Icon size={size} aria-hidden="true" />
}
