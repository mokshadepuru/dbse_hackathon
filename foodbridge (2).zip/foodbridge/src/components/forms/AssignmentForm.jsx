import useForm from '../../hooks/useForm'
import { toLocalInput, fmtDateTime, timeLeft } from '../../utils/calculations'
import { SelectField, TextField } from './Fields'
import FormActions from './FormActions'

// Pick a request, then a package of the same category. Servings are capped to what is available and needed.
export default function AssignmentForm({ requests, packages, volunteers, ngos, initial, onSubmit, onCancel }) {
  const ngoName = (id) => ngos.find((n) => n.id === id)?.name
  const validate = (v) => {
    const pkg = packages.find((p) => p.id === v.packageId)
    const req = requests.find((r) => r.id === v.requestId)
    const n = Number(v.servings)
    return {
      requestId: !v.requestId && 'Choose a request.',
      packageId: !v.packageId && 'Choose a package.',
      servings: !Number.isInteger(n) || n < 1 ? 'Enter whole servings, at least 1.'
        : pkg && n > pkg.availableServings ? `Only ${pkg.availableServings} servings are available.`
        : req && n > req.quantity ? `The request only needs ${req.quantity} servings.` : '',
      volunteerId: !v.volunteerId && 'Choose a volunteer.',
      pickupAt: !v.pickupAt && 'Choose a pickup time.',
    }
  }
  // If we arrive with only a request chosen (for example from the Requests page), pre-select the best package.
  const start = { requestId: '', packageId: '', servings: '', volunteerId: '', pickupAt: toLocalInput(Date.now() + 3600 * 1000), ...initial }
  const startReq = requests.find((r) => r.id === start.requestId)
  if (startReq && !start.packageId) {
    const first = packages.find((p) => p.category === startReq.category)
    if (first) Object.assign(start, { packageId: first.id, servings: Math.min(startReq.quantity, first.availableServings) })
  }
  const f = useForm(start, validate)
  const { values: v, errors: e } = f
  const req = requests.find((r) => r.id === v.requestId)
  const pkgOptions = packages.filter((p) => !req || p.category === req.category)
  const pkg = packages.find((p) => p.id === v.packageId)

  const pickRequest = (ev) => {
    const r = requests.find((x) => x.id === ev.target.value)
    const first = r && packages.find((p) => p.category === r.category)
    f.setValues((s) => ({ ...s, requestId: ev.target.value, packageId: first?.id || '', servings: r && first ? Math.min(r.quantity, first.availableServings) : '' }))
  }
  const pickPackage = (ev) => {
    const p = packages.find((x) => x.id === ev.target.value)
    f.setValues((s) => ({ ...s, packageId: ev.target.value, servings: p && req ? Math.min(req.quantity, p.availableServings) : s.servings }))
  }

  return (
    <form onSubmit={f.handleSubmit((vals) => onSubmit({ ...vals, servings: Number(vals.servings), pickupAt: new Date(vals.pickupAt).toISOString() }))} noValidate>
      <SelectField label="Request" required placeholder="Select a request" value={v.requestId} onChange={pickRequest} error={e.requestId}
        options={requests.map((r) => ({ value: r.id, label: `${r.id} - ${ngoName(r.ngoId)} - ${r.quantity} ${r.category} (${r.urgency})` }))} />
      {req && <p className="info-line">Needed {fmtDateTime(req.neededBy)} ({timeLeft(req.neededBy)}) in {req.location}</p>}
      <SelectField label="Food package" required placeholder={req ? 'Select a matching package' : 'Choose a request first'} value={v.packageId} onChange={pickPackage} error={e.packageId}
        options={pkgOptions.map((p) => ({ value: p.id, label: `${p.id} - ${p.name} - ${p.availableServings} servings left (${p.location})` }))} />
      {req && pkgOptions.length === 0 && <p className="field-error">No available package matches {req.category}.</p>}
      <div className="form-grid">
        <TextField label="Assigned servings" type="number" min="1" required value={v.servings} onChange={f.bind('servings')} error={e.servings}
          hint={pkg && req ? `Max ${Math.min(pkg.availableServings, req.quantity)}` : undefined} />
        <SelectField label="Volunteer / delivery partner" required placeholder="Select volunteer" value={v.volunteerId} onChange={f.bind('volunteerId')} error={e.volunteerId}
          options={volunteers.map((x) => ({ value: x.id, label: `${x.name} (${x.vehicle}, ${x.area})` }))} />
        <TextField label="Pickup date and time" type="datetime-local" required value={v.pickupAt} onChange={f.bind('pickupAt')} error={e.pickupAt} />
      </div>
      <FormActions onCancel={onCancel} saving={f.saving} submitLabel="Create assignment" />
    </form>
  )
}
