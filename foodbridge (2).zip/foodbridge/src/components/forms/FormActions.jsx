export default function FormActions({ onCancel, saving, submitLabel = 'Save' }) {
  return (
    <div className="form-actions">
      <button type="button" className="btn btn-secondary" onClick={onCancel}>Cancel</button>
      <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving...' : submitLabel}</button>
    </div>
  )
}
