import { useId } from 'react'

// Label + control + error message, wired together for screen readers.
export function Field({ label, error, hint, required, children }) {
  return (
    <div className={`field ${error ? 'has-error' : ''}`}>
      <label className="field-label">{label}{required && <span aria-hidden="true"> *</span>}</label>
      {children}
      {hint && !error && <span className="field-hint">{hint}</span>}
      {error && <span className="field-error" role="alert">{error}</span>}
    </div>
  )
}

function useFieldId(props) {
  const generated = useId()
  return props.id || generated
}

export function TextField({ label, error, hint, required, ...props }) {
  const id = useFieldId(props)
  return (
    <div className={`field ${error ? 'has-error' : ''}`}>
      <label className="field-label" htmlFor={id}>{label}{required && <span aria-hidden="true"> *</span>}</label>
      <input id={id} className="input" aria-invalid={!!error} aria-required={required} {...props} />
      {hint && !error && <span className="field-hint">{hint}</span>}
      {error && <span className="field-error" role="alert">{error}</span>}
    </div>
  )
}

export function SelectField({ label, error, required, options, placeholder, ...props }) {
  const id = useFieldId(props)
  return (
    <div className={`field ${error ? 'has-error' : ''}`}>
      <label className="field-label" htmlFor={id}>{label}{required && <span aria-hidden="true"> *</span>}</label>
      <select id={id} className="input" aria-invalid={!!error} {...props}>
        {placeholder && <option value="">{placeholder}</option>}
        {options.map((o) => (
          <option key={o.value ?? o} value={o.value ?? o}>{o.label ?? o}</option>
        ))}
      </select>
      {error && <span className="field-error" role="alert">{error}</span>}
    </div>
  )
}

export function TextAreaField({ label, error, required, ...props }) {
  const id = useFieldId(props)
  return (
    <div className={`field ${error ? 'has-error' : ''}`}>
      <label className="field-label" htmlFor={id}>{label}{required && <span aria-hidden="true"> *</span>}</label>
      <textarea id={id} className="input" rows={3} aria-invalid={!!error} {...props} />
      {error && <span className="field-error" role="alert">{error}</span>}
    </div>
  )
}

// Tiny helper used by all forms: a state object + setter per field + error object.
export const emailOk = (v) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)
export const phoneOk = (v) => /^[+]?[\d\s-]{8,16}$/.test(v)
