import useForm from '../../hooks/useForm'
import { CATEGORIES, LOCATIONS, URGENCY } from '../../data/constants'
import { toLocalInput } from '../../utils/calculations'
import { TextField, SelectField, TextAreaField } from './Fields'
import FormActions from './FormActions'

export default function RequestForm({ ngos, fixedNgoId, initial, onSubmit, onCancel }) {
  const validate = (v) => ({
    ngoId: !v.ngoId && 'Choose the NGO.',
    quantity: !Number.isInteger(Number(v.quantity)) || Number(v.quantity) < 1 ? 'Enter whole servings, at least 1.' : '',
    beneficiaries: !Number.isInteger(Number(v.beneficiaries)) || Number(v.beneficiaries) < 1 ? 'Enter how many people will be fed.' : '',
    neededBy: !v.neededBy ? 'Choose when the food is needed.' : new Date(v.neededBy).getTime() <= Date.now() ? 'Choose a time in the future.' : '',
    location: !v.location && 'Choose the delivery location.',
    reason: v.reason.trim().length < 10 && 'Explain the need in at least 10 characters.',
  })
  const ngo = (id) => ngos.find((n) => n.id === id)
  const f = useForm({
    ngoId: fixedNgoId || '', category: CATEGORIES[0], quantity: '', beneficiaries: '', location: '', urgency: 'Medium', reason: '',
    neededBy: toLocalInput(Date.now() + 12 * 3600 * 1000), ...initial,
  }, validate)
  const { values: v, errors: e, bind } = f
  const submit = (vals) =>
    onSubmit({ ngoId: vals.ngoId, category: vals.category, quantity: Number(vals.quantity), beneficiaries: Number(vals.beneficiaries), neededBy: new Date(vals.neededBy).toISOString(), location: vals.location, urgency: vals.urgency, reason: vals.reason.trim() })
  return (
    <form onSubmit={f.handleSubmit(submit)} noValidate>
      <div className="form-grid">
        <SelectField label="NGO" required placeholder="Select NGO" disabled={!!fixedNgoId} value={v.ngoId} error={e.ngoId}
          onChange={(ev) => { bind('ngoId')(ev); const n = ngo(ev.target.value); if (n && !v.location) f.set('location', n.serviceArea) }}
          options={ngos.map((n) => ({ value: n.id, label: n.name }))} />
        <SelectField label="Food category" options={CATEGORIES} value={v.category} onChange={bind('category')} />
        <TextField label="Quantity (servings)" type="number" min="1" required value={v.quantity} onChange={bind('quantity')} error={e.quantity} />
        <TextField label="Beneficiaries" type="number" min="1" required value={v.beneficiaries} onChange={bind('beneficiaries')} error={e.beneficiaries} />
        <TextField label="Needed by" type="datetime-local" required value={v.neededBy} onChange={bind('neededBy')} error={e.neededBy} />
        <SelectField label="Delivery location" required placeholder="Select area" options={LOCATIONS} value={v.location} onChange={bind('location')} error={e.location} />
        <SelectField label="Urgency" options={URGENCY} value={v.urgency} onChange={bind('urgency')} />
      </div>
      <TextAreaField label="Reason for request" required value={v.reason} onChange={bind('reason')} error={e.reason} />
      <FormActions onCancel={onCancel} saving={f.saving} submitLabel="Submit request" />
    </form>
  )
}
