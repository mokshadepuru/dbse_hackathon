import useForm from '../../hooks/useForm'
import { CATEGORIES, DIETS, LOCATIONS, UNITS } from '../../data/constants'
import { toLocalInput } from '../../utils/calculations'
import { TextField, SelectField, TextAreaField } from './Fields'
import FormActions from './FormActions'

export default function PackageForm({ pkg, donors, fixedDonorId, assignedServings = 0, onSubmit, onCancel }) {
  const validate = (v) => {
    const prepared = new Date(v.preparedAt).getTime()
    const expires = new Date(v.expiresAt).getTime()
    return {
      name: !v.name.trim() && 'Enter a package name.',
      donorId: !v.donorId && 'Choose the donor.',
      quantity: !(Number(v.quantity) > 0) && 'Enter a quantity greater than 0.',
      servings: !Number.isInteger(Number(v.servings)) || Number(v.servings) < 1 ? 'Enter whole servings, at least 1.'
        : Number(v.servings) < assignedServings ? `${assignedServings} servings are already assigned.` : '',
      preparedAt: !v.preparedAt && 'Choose the preparation time.',
      expiresAt: !v.expiresAt ? 'Choose the expiry time.'
        : expires <= prepared ? 'Expiry must be after the preparation time.'
        : !pkg && expires <= Date.now() ? 'Expiry must be in the future.' : '',
      location: !v.location && 'Choose the pickup location.',
    }
  }
  const f = useForm(
    pkg
      ? { ...pkg, preparedAt: toLocalInput(pkg.preparedAt), expiresAt: toLocalInput(pkg.expiresAt) }
      : { name: '', donorId: fixedDonorId || '', category: CATEGORIES[0], description: '', quantity: '', unit: 'kg', servings: '', preparedAt: toLocalInput(), expiresAt: toLocalInput(Date.now() + 6 * 3600 * 1000), location: '', diet: 'Vegetarian', notes: '' },
    validate,
  )
  const { values: v, errors: e, bind } = f
  const submit = (vals) =>
    onSubmit({
      name: vals.name.trim(), donorId: vals.donorId, category: vals.category, description: vals.description,
      quantity: Number(vals.quantity), unit: vals.unit, servings: Number(vals.servings),
      preparedAt: new Date(vals.preparedAt).toISOString(), expiresAt: new Date(vals.expiresAt).toISOString(),
      location: vals.location, diet: vals.diet, notes: vals.notes,
    })
  return (
    <form onSubmit={f.handleSubmit(submit)} noValidate>
      <div className="form-grid">
        <TextField label="Package name" required value={v.name} onChange={bind('name')} error={e.name} />
        <SelectField label="Donor" required placeholder="Select donor" disabled={!!fixedDonorId} value={v.donorId} onChange={bind('donorId')} error={e.donorId}
          options={donors.map((d) => ({ value: d.id, label: `${d.organization} (${d.id})` }))} />
        <SelectField label="Category" options={CATEGORIES} value={v.category} onChange={bind('category')} />
        <SelectField label="Food type" options={DIETS} value={v.diet} onChange={bind('diet')} />
        <TextField label="Quantity" type="number" min="0" step="any" required value={v.quantity} onChange={bind('quantity')} error={e.quantity} />
        <SelectField label="Unit" options={UNITS} value={v.unit} onChange={bind('unit')} />
        <TextField label="Estimated servings" type="number" min="1" required value={v.servings} onChange={bind('servings')} error={e.servings} />
        <SelectField label="Pickup location" required placeholder="Select area" options={LOCATIONS} value={v.location} onChange={bind('location')} error={e.location} />
        <TextField label="Prepared / available from" type="datetime-local" required value={v.preparedAt} onChange={bind('preparedAt')} error={e.preparedAt} />
        <TextField label="Expires at" type="datetime-local" required value={v.expiresAt} onChange={bind('expiresAt')} error={e.expiresAt} />
      </div>
      <TextAreaField label="Description" value={v.description} onChange={bind('description')} />
      <TextAreaField label="Food safety and handling notes" value={v.notes} onChange={bind('notes')} />
      <FormActions onCancel={onCancel} saving={f.saving} submitLabel={pkg ? 'Save changes' : 'List package'} />
    </form>
  )
}
