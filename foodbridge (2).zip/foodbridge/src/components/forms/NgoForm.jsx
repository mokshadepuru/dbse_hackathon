import useForm from '../../hooks/useForm'
import { CATEGORIES, LOCATIONS, VERIFICATION } from '../../data/constants'
import { TextField, SelectField, Field, emailOk, phoneOk } from './Fields'
import FormActions from './FormActions'

const validate = (v) => ({
  name: !v.name.trim() && 'Enter the NGO name.',
  contactPerson: !v.contactPerson.trim() && 'Enter a contact person.',
  phone: !v.phone.trim() ? 'Enter a phone number.' : !phoneOk(v.phone) ? 'Use digits only, for example +91 90000 20001.' : '',
  email: !v.email.trim() ? 'Enter an email address.' : !emailOk(v.email) ? 'Enter a valid email like name@example.com.' : '',
  serviceArea: !v.serviceArea && 'Choose a service area.',
  beneficiaries: v.beneficiaries === '' || Number(v.beneficiaries) < 0 ? 'Enter the number of beneficiaries (0 or more).' : '',
  capacity: v.capacity === '' || Number(v.capacity) < 0 ? 'Enter the daily capacity in meals (0 or more).' : '',
})

export default function NgoForm({ ngo, canVerify, onSubmit, onCancel }) {
  const f = useForm(ngo || { name: '', verification: 'Pending', contactPerson: '', phone: '', email: '', address: '', serviceArea: '', beneficiaries: '', capacity: '', requirements: [] }, validate)
  const { values: v, errors: e, bind } = f
  const toggle = (c) => f.set('requirements', v.requirements.includes(c) ? v.requirements.filter((x) => x !== c) : [...v.requirements, c])
  const submit = (vals) => onSubmit({ ...vals, beneficiaries: Number(vals.beneficiaries), capacity: Number(vals.capacity) })
  return (
    <form onSubmit={f.handleSubmit(submit)} noValidate>
      <div className="form-grid">
        <TextField label="NGO name" required value={v.name} onChange={bind('name')} error={e.name} />
        <SelectField label="Verification status" options={VERIFICATION} value={v.verification} onChange={bind('verification')} disabled={!canVerify} />
        <TextField label="Contact person" required value={v.contactPerson} onChange={bind('contactPerson')} error={e.contactPerson} />
        <TextField label="Phone" required value={v.phone} onChange={bind('phone')} error={e.phone} />
        <TextField label="Email" type="email" required value={v.email} onChange={bind('email')} error={e.email} />
        <SelectField label="Service area" required placeholder="Select area" options={LOCATIONS} value={v.serviceArea} onChange={bind('serviceArea')} error={e.serviceArea} />
        <TextField label="Beneficiaries served" type="number" min="0" required value={v.beneficiaries} onChange={bind('beneficiaries')} error={e.beneficiaries} />
        <TextField label="Distribution capacity (meals/day)" type="number" min="0" required value={v.capacity} onChange={bind('capacity')} error={e.capacity} />
      </div>
      <TextField label="Address" value={v.address} onChange={bind('address')} />
      <Field label="Food requirements">
        <div className="chip-row">
          {CATEGORIES.map((c) => (
            <label key={c} className={`chip ${v.requirements.includes(c) ? 'chip-on' : ''}`}>
              <input type="checkbox" checked={v.requirements.includes(c)} onChange={() => toggle(c)} /> {c}
            </label>
          ))}
        </div>
      </Field>
      <FormActions onCancel={onCancel} saving={f.saving} submitLabel={ngo ? 'Save changes' : 'Add NGO'} />
    </form>
  )
}
