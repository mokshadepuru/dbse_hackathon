import useForm from '../../hooks/useForm'
import { DONOR_TYPES, LOCATIONS } from '../../data/constants'
import { TextField, SelectField, emailOk, phoneOk } from './Fields'
import FormActions from './FormActions'

const validate = (v) => ({
  name: !v.name.trim() && 'Enter the contact person’s name.',
  organization: !v.organization.trim() && 'Enter the organisation or restaurant name.',
  phone: !v.phone.trim() ? 'Enter a phone number.' : !phoneOk(v.phone) ? 'Use digits only, for example +91 98480 10001.' : '',
  email: !v.email.trim() ? 'Enter an email address.' : !emailOk(v.email) ? 'Enter a valid email like name@example.com.' : '',
  location: !v.location && 'Choose a location.',
})

export default function DonorForm({ donor, onSubmit, onCancel }) {
  const f = useForm(donor || { name: '', organization: '', type: 'Restaurant', phone: '', email: '', location: '', address: '', status: 'Active' }, validate)
  const { values: v, errors: e, bind } = f
  return (
    <form onSubmit={f.handleSubmit(onSubmit)} noValidate>
      <div className="form-grid">
        <TextField label="Contact person" required value={v.name} onChange={bind('name')} error={e.name} />
        <TextField label="Organisation / restaurant" required value={v.organization} onChange={bind('organization')} error={e.organization} />
        <SelectField label="Donor type" options={DONOR_TYPES} value={v.type} onChange={bind('type')} />
        <SelectField label="Status" options={['Active', 'Inactive']} value={v.status} onChange={bind('status')} />
        <TextField label="Phone" required value={v.phone} onChange={bind('phone')} error={e.phone} />
        <TextField label="Email" type="email" required value={v.email} onChange={bind('email')} error={e.email} />
        <SelectField label="Location" required placeholder="Select area" options={LOCATIONS} value={v.location} onChange={bind('location')} error={e.location} />
        <TextField label="Street address" value={v.address} onChange={bind('address')} />
      </div>
      <FormActions onCancel={onCancel} saving={f.saving} submitLabel={donor ? 'Save changes' : 'Add donor'} />
    </form>
  )
}
