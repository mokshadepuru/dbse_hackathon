import { Navigate, Route, Routes, useLocation } from 'react-router-dom'
import { useApp } from './context/AppContext'
import AppLayout from './components/layout/AppLayout'
import { NAV_ITEMS } from './components/layout/navConfig'
import Toasts from './components/common/Toasts'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import Donors from './pages/Donors'
import FoodPackages from './pages/FoodPackages'
import NGOs from './pages/NGOs'
import Requests from './pages/Requests'
import Assignments from './pages/Assignments'
import DistributionHistory from './pages/DistributionHistory'
import DemandInsights from './pages/DemandInsights'
import Analytics from './pages/Analytics'
import Settings from './pages/Settings'

const PAGES = {
  '/dashboard': Dashboard, '/packages': FoodPackages, '/requests': Requests, '/assignments': Assignments,
  '/history': DistributionHistory, '/donors': Donors, '/ngos': NGOs, '/insights': DemandInsights,
  '/analytics': Analytics, '/settings': Settings,
}

// Only logged-in users can see the app; menu roles also protect the URLs.
function Protected({ children }) {
  const { user } = useApp()
  const loc = useLocation()
  if (!user) return <Navigate to="/login" replace state={{ from: loc.pathname }} />
  return children
}

export default function App() {
  const { user } = useApp()
  return (
    <>
      <Routes>
        <Route path="/login" element={user ? <Navigate to="/dashboard" replace /> : <Login />} />
        <Route element={<Protected><AppLayout /></Protected>}>
          <Route index element={<Navigate to="/dashboard" replace />} />
          {NAV_ITEMS.map(({ to, roles }) => {
            const Page = PAGES[to]
            return <Route key={to} path={to} element={user && !roles.includes(user.role) ? <Navigate to="/dashboard" replace /> : <Page />} />
          })}
        </Route>
        <Route path="*" element={<Navigate to={user ? '/dashboard' : '/login'} replace />} />
      </Routes>
      <Toasts />
    </>
  )
}
